
# MLAI Market Language Brain — Core Implementation
# Phase P0-P2 Foundation
# Aligned with MLAI Architecture Document and v3.4.3 validation principles

import os
import json
import math
import random
import hashlib
import pickle
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple, Any, Callable, FrozenSet
from datetime import datetime, timezone
from collections import defaultdict, Counter
from enum import Enum, auto
import copy

# ============================================================================
# SECTION 1: DATA CONTRACTS & IMMUTABILITY (Phase P0)
# ============================================================================

class DataStatus(Enum):
    RAW = auto()
    NORMALIZED = auto()
    DERIVED = auto()
    VALIDATED = auto()
    REJECTED = auto()

@dataclass(frozen=True)
class RawCandle:
    """Immutable raw data record."""
    instrument: str
    timeframe: str
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    source: str
    retrieved_at: str

    def __post_init__(self):
        if not (self.low <= self.open <= self.high and 
                self.low <= self.close <= self.high and
                self.low <= self.high):
            raise ValueError(f"Invalid OHLC: {self}")

    def hash(self) -> str:
        data = f"{self.instrument}:{self.timeframe}:{self.timestamp}:{self.open}:{self.high}:{self.low}:{self.close}:{self.volume}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]

    def to_canonical(self) -> 'CanonicalCandle':
        return CanonicalCandle(
            instrument=self.instrument,
            timeframe=self.timeframe,
            timestamp=self.timestamp,
            open=self.open,
            high=self.high,
            low=self.low,
            close=self.close,
            volume=self.volume,
            volume_type="base",
            source=self.source,
            raw_hash=self.hash()
        )

@dataclass(frozen=True)
class CanonicalCandle:
    """Normalized, validated candle."""
    instrument: str
    timeframe: str
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    volume_type: str
    source: str
    raw_hash: str

@dataclass
class DataQualityReport:
    """Quality metadata for a dataset."""
    total_records: int = 0
    missing_fields: int = 0
    invalid_ohlc: int = 0
    duplicate_timestamps: int = 0
    out_of_order: int = 0
    time_gaps: int = 0
    rejected: int = 0
    accepted: int = 0

    def is_valid(self) -> bool:
        return (self.invalid_ohlc == 0 and 
                self.out_of_order == 0 and
                self.duplicate_timestamps == 0)

class ImmutableDataStore:
    """Append-only raw data with integrity protection."""

    def __init__(self, storage_path: str):
        self.storage_path = storage_path
        self.raw_candles: List[RawCandle] = []
        self._hashes: set = set()
        self._load()

    def _load(self):
        if os.path.exists(self.storage_path):
            with open(self.storage_path, 'rb') as f:
                data = pickle.load(f)
                self.raw_candles = data.get('candles', [])
                self._hashes = {c.hash() for c in self.raw_candles}

    def append(self, candle: RawCandle) -> bool:
        h = candle.hash()
        if h in self._hashes:
            return False
        self.raw_candles.append(candle)
        self._hashes.add(h)
        return True

    def save(self):
        os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
        with open(self.storage_path, 'wb') as f:
            pickle.dump({'candles': self.raw_candles, 'saved_at': datetime.now(timezone.utc).isoformat()}, f)

    def get_instrument_data(self, instrument: str, timeframe: str) -> List[RawCandle]:
        return [c for c in self.raw_candles 
                if c.instrument == instrument and c.timeframe == timeframe]

    def validate_chronology(self, instrument: str, timeframe: str) -> DataQualityReport:
        candles = self.get_instrument_data(instrument, timeframe)
        report = DataQualityReport(total_records=len(candles))
        if len(candles) < 2:
            return report
        sorted_candles = sorted(candles, key=lambda c: c.timestamp)
        for i in range(1, len(sorted_candles)):
            if sorted_candles[i].timestamp <= sorted_candles[i-1].timestamp:
                if sorted_candles[i].timestamp == sorted_candles[i-1].timestamp:
                    report.duplicate_timestamps += 1
                else:
                    report.out_of_order += 1
        report.accepted = len(candles) - report.rejected
        return report


# ============================================================================
# SECTION 2: CAUSALITY CONTRACT (Phase P0)
# ============================================================================

class FeatureType(Enum):
    CAUSAL_INPUT = "causal_input"
    DELAYED_CAUSAL = "delayed_causal"
    FUTURE_TARGET = "future_target"
    EVAL_ONLY = "eval_only"
    PROHIBITED = "prohibited"

@dataclass(frozen=True)
class CausalityEntry:
    feature_name: str
    required_info: str
    first_available: str
    feature_type: FeatureType
    calculation_delay: int = 0

class CausalityRegistry:
    """Prevents look-ahead bias through explicit feature registration."""

    def __init__(self):
        self._registry: Dict[str, CausalityEntry] = {}
        self._build_defaults()

    def _build_defaults(self):
        defaults = [
            CausalityEntry("candle_body", "Current candle close", "candle_close", FeatureType.CAUSAL_INPUT),
            CausalityEntry("current_atr", "Current and prior N candles", "candle_close", FeatureType.DELAYED_CAUSAL, 1),
            CausalityEntry("confirmed_swing", "Swing plus confirmation candles", "confirmation_close", FeatureType.DELAYED_CAUSAL, 3),
            CausalityEntry("future_return_h4", "Future 4 candles", "h4_future", FeatureType.FUTURE_TARGET),
            CausalityEntry("future_return_h8", "Future 8 candles", "h8_future", FeatureType.FUTURE_TARGET),
            CausalityEntry("future_return_h16", "Future 16 candles", "h16_future", FeatureType.FUTURE_TARGET),
            CausalityEntry("htf_state", "Completed higher-timeframe candle", "htf_close", FeatureType.DELAYED_CAUSAL),
            CausalityEntry("mfe", "Future maximum favorable excursion", "future_complete", FeatureType.FUTURE_TARGET),
            CausalityEntry("mae", "Future maximum adverse excursion", "future_complete", FeatureType.FUTURE_TARGET),
        ]
        for entry in defaults:
            self.register(entry)

    def register(self, entry: CausalityEntry):
        self._registry[entry.feature_name] = entry

    def is_valid_for_inference(self, feature_name: str) -> bool:
        entry = self._registry.get(feature_name)
        if not entry:
            return False
        return entry.feature_type in (FeatureType.CAUSAL_INPUT, FeatureType.DELAYED_CAUSAL)

    def is_target(self, feature_name: str) -> bool:
        entry = self._registry.get(feature_name)
        if not entry:
            return False
        return entry.feature_type == FeatureType.FUTURE_TARGET

    def audit_feature_set(self, features: List[str]) -> Tuple[List[str], List[str]]:
        valid = []
        violations = []
        for f in features:
            if self.is_valid_for_inference(f):
                valid.append(f)
            elif self.is_target(f):
                violations.append(f"{f}: target used as input")
            elif self._registry.get(f) and self._registry[f].feature_type == FeatureType.PROHIBITED:
                violations.append(f"{f}: prohibited feature")
            else:
                violations.append(f"{f}: unregistered feature")
        return valid, violations


# ============================================================================
# SECTION 3: MARKET LANGUAGE REPRESENTATION (Phase P1)
# ============================================================================

@dataclass
class CandleAnatomy:
    body: float
    abs_body: float
    upper_wick: float
    lower_wick: float
    range: float
    body_range_ratio: float
    upper_wick_body_ratio: float
    lower_wick_body_ratio: float
    direction: str
    relative_size: float
    relative_body_size: float
    is_expansion: bool
    is_compression: bool
    location_in_range: float

@dataclass
class RelativeMovement:
    return_5: float
    return_10: float
    return_20: float
    return_60: float
    atr_normalized_move: float
    distance_from_recent_high: float
    distance_from_recent_low: float
    position_in_recent_range: float
    rate_of_movement: float
    acceleration: float
    deceleration: bool

@dataclass
class SequenceState:
    current_phase: str
    previous_phases: List[str]
    impulse_detected: bool
    correction_detected: bool
    pullback_detected: bool
    rejection_detected: bool
    recovery_detected: bool
    momentum_loss: bool
    exhaustion_detected: bool
    consolidation: bool
    compression: bool
    breakout_detected: bool
    failed_breakout: bool
    retest_detected: bool
    continuation_likely: bool
    reversal_candidate: bool
    transition_detected: bool
    description: str = ""

@dataclass
class MarketStructure:
    swing_highs: List[Tuple[int, float]] = field(default_factory=list)
    swing_lows: List[Tuple[int, float]] = field(default_factory=list)
    higher_highs: bool = False
    higher_lows: bool = False
    lower_highs: bool = False
    lower_lows: bool = False
    trend: str = "undefined"
    range_state: bool = False
    bos_detected: bool = False
    choch_detected: bool = False
    structural_failure: bool = False
    structural_transition: bool = False
    continuation_likely: bool = False
    reversal_candidate: bool = False

@dataclass
class SupportResistanceArea:
    price_low: float
    price_high: float
    creation_reason: str
    num_tests: int
    reaction_strength: float
    freshness: float
    is_broken: bool
    is_retested: bool
    is_failed: bool
    role_reversal: bool

@dataclass
class MomentumState:
    momentum_increasing: bool
    momentum_decreasing: bool
    accelerating: bool
    exhausted: bool
    directional_strength: float
    follow_through: bool
    failed_push: bool
    momentum_disagreement: bool

@dataclass
class RegimeState:
    trending: bool
    ranging: bool
    high_volatility: bool
    low_volatility: bool
    volatility_expanding: bool
    volatility_contracting: bool
    transitioning: bool
    strong_directional: bool
    weak_directional: bool
    regime_label: str = "unknown"

@dataclass
class ContextState:
    instrument: str
    timeframe: str
    session: str
    trend_context: str
    range_context: str
    location: str
    previous_movement: str
    structure_state: str
    volatility_state: str
    momentum_state: str
    volume_available: bool
    recent_reactions: List[str] = field(default_factory=list)
    htf_context: Optional[str] = None

@dataclass
class MarketState:
    timestamp: int
    index: int
    candle_anatomy: CandleAnatomy
    relative_movement: RelativeMovement
    sequence: SequenceState
    structure: MarketStructure
    support_resistance: List[SupportResistanceArea]
    momentum: MomentumState
    regime: RegimeState
    context: ContextState

    def to_feature_vector(self) -> Dict[str, Any]:
        features = {}
        ca = self.candle_anatomy
        features.update({
            "body_range_ratio": ca.body_range_ratio,
            "upper_wick_dominant": ca.upper_wick_body_ratio > 1.0,
            "lower_wick_dominant": ca.lower_wick_body_ratio > 1.0,
            "direction": ca.direction,
            "expansion": ca.is_expansion,
            "compression": ca.is_compression,
            "location_in_candle_range": ca.location_in_range,
        })
        rm = self.relative_movement
        features.update({
            "return_5_bucket": self._bucket_return(rm.return_5),
            "return_20_bucket": self._bucket_return(rm.return_20),
            "near_recent_high": rm.distance_from_recent_high < 0.02,
            "near_recent_low": rm.distance_from_recent_low < 0.02,
            "accelerating": rm.acceleration > 0,
            "decelerating": rm.deceleration,
        })
        seq = self.sequence
        features.update({
            "phase": seq.current_phase,
            "rejection": seq.rejection_detected,
            "recovery": seq.recovery_detected,
            "exhaustion": seq.exhaustion_detected,
            "consolidation": seq.consolidation,
            "breakout": seq.breakout_detected,
            "failed_breakout": seq.failed_breakout,
        })
        st = self.structure
        features.update({
            "trend": st.trend,
            "range_state": st.range_state,
            "bos": st.bos_detected,
            "choch": st.choch_detected,
            "structural_transition": st.structural_transition,
        })
        mo = self.momentum
        features.update({
            "momentum_increasing": mo.momentum_increasing,
            "momentum_decreasing": mo.momentum_decreasing,
            "exhausted": mo.exhausted,
            "follow_through": mo.follow_through,
        })
        reg = self.regime
        features.update({
            "regime": reg.regime_label,
            "high_volatility": reg.high_volatility,
            "trending": reg.trending,
            "ranging": reg.ranging,
        })
        ctx = self.context
        features.update({
            "location": ctx.location,
            "htf_context": ctx.htf_context or "unknown",
        })
        return features

    @staticmethod
    def _bucket_return(ret: float) -> str:
        if ret > 0.01: return "strong_up"
        if ret > 0.005: return "up"
        if ret > -0.005: return "neutral"
        if ret > -0.01: return "down"
        return "strong_down"


# ============================================================================
# SECTION 4: MARKET STATE BUILDER
# ============================================================================

class MarketStateBuilder:
    """Builds complete MarketState from candle history."""

    def __init__(self, causality: CausalityRegistry, atr_period: int = 14):
        self.causality = causality
        self.atr_period = atr_period

    def build_state(self, candles: List[CanonicalCandle], index: int) -> Optional[MarketState]:
        if index < 20 or index >= len(candles):
            return None
        current = candles[index]
        window = candles[max(0, index-60):index+1]
        recent = candles[max(0, index-20):index+1]

        anatomy = self._build_anatomy(current, recent)
        movement = self._build_movement(candles, index)
        sequence = self._build_sequence(candles, index)
        structure = self._build_structure(candles, index)
        sr_areas = self._build_support_resistance(candles, index)
        momentum = self._build_momentum(candles, index)
        regime = self._build_regime(candles, index)
        context = self._build_context(current, structure, regime, candles, index)

        return MarketState(
            timestamp=current.timestamp,
            index=index,
            candle_anatomy=anatomy,
            relative_movement=movement,
            sequence=sequence,
            structure=structure,
            support_resistance=sr_areas,
            momentum=momentum,
            regime=regime,
            context=context
        )

    def _build_anatomy(self, candle: CanonicalCandle, recent: List[CanonicalCandle]) -> CandleAnatomy:
        body = candle.close - candle.open
        abs_body = abs(body)
        range_val = candle.high - candle.low
        upper_wick = candle.high - max(candle.open, candle.close)
        lower_wick = min(candle.open, candle.close) - candle.low
        body_range_ratio = abs_body / range_val if range_val > 0 else 0
        uw_ratio = upper_wick / abs_body if abs_body > 0 else float('inf')
        lw_ratio = lower_wick / abs_body if abs_body > 0 else float('inf')
        direction = "bullish" if body > 0 else "bearish" if body < 0 else "neutral"
        avg_range = sum(c.high - c.low for c in recent) / len(recent) if recent else 1
        relative_size = range_val / avg_range if avg_range > 0 else 1
        avg_body = sum(abs(c.close - c.open) for c in recent) / len(recent) if recent else 1
        relative_body_size = abs_body / avg_body if avg_body > 0 else 1
        is_expansion = relative_size > 1.5
        is_compression = relative_size < 0.6
        location = (candle.close - candle.low) / range_val if range_val > 0 else 0.5

        return CandleAnatomy(
            body=body, abs_body=abs_body,
            upper_wick=upper_wick, lower_wick=lower_wick,
            range=range_val, body_range_ratio=body_range_ratio,
            upper_wick_body_ratio=uw_ratio, lower_wick_body_ratio=lw_ratio,
            direction=direction, relative_size=relative_size,
            relative_body_size=relative_body_size,
            is_expansion=is_expansion, is_compression=is_compression,
            location_in_range=location
        )

    def _build_movement(self, candles: List[CanonicalCandle], index: int) -> RelativeMovement:
        c = candles[index]
        def ret(n: int) -> float:
            if index - n < 0: return 0.0
            base = candles[index - n].close
            return (c.close / base - 1.0) if base != 0 else 0.0
        recent = candles[max(0, index-20):index+1]
        highs = [x.high for x in recent]
        lows = [x.low for x in recent]
        recent_high = max(highs) if highs else c.high
        recent_low = min(lows) if lows else c.low
        atr = self._calculate_atr(candles, index)
        atr_norm = (c.high - c.low) / atr if atr > 0 else 0
        dist_high = (recent_high - c.close) / recent_high if recent_high > 0 else 0
        dist_low = (c.close - recent_low) / recent_low if recent_low > 0 else 0
        pos_range = (c.close - recent_low) / (recent_high - recent_low) if recent_high != recent_low else 0.5
        rate = ret(5) / 5 if index >= 5 else 0
        accel = ret(5) - ret(10) if index >= 10 else 0
        decel = ret(5) < ret(10) if index >= 10 else False
        return RelativeMovement(
            return_5=ret(5), return_10=ret(10), return_20=ret(20), return_60=ret(60),
            atr_normalized_move=atr_norm,
            distance_from_recent_high=dist_high,
            distance_from_recent_low=dist_low,
            position_in_recent_range=pos_range,
            rate_of_movement=rate,
            acceleration=accel,
            deceleration=decel
        )

    def _calculate_atr(self, candles: List[CanonicalCandle], index: int) -> float:
        if index < 1: return 0
        trs = []
        for i in range(max(1, index-self.atr_period+1), index+1):
            c = candles[i]
            p = candles[i-1]
            tr = max(c.high - c.low, abs(c.high - p.close), abs(c.low - p.close))
            trs.append(tr)
        return sum(trs) / len(trs) if trs else 0

    def _build_sequence(self, candles: List[CanonicalCandle], index: int) -> SequenceState:
        recent = candles[max(0, index-10):index+1]
        if len(recent) < 5:
            return SequenceState(current_phase="unknown", previous_phases=[], 
                               impulse_detected=False, correction_detected=False,
                               pullback_detected=False, rejection_detected=False,
                               recovery_detected=False, momentum_loss=False,
                               exhaustion_detected=False, consolidation=False,
                               compression=False, breakout_detected=False,
                               failed_breakout=False, retest_detected=False,
                               continuation_likely=False, reversal_candidate=False,
                               transition_detected=False, description="")
        bodies = [c.close - c.open for c in recent]
        directions = [1 if b > 0 else -1 if b < 0 else 0 for b in bodies]
        phase = "consolidation"
        if sum(directions[-3:]) >= 2: phase = "impulse"
        elif sum(directions[-3:]) <= -2: phase = "decline"
        elif directions[-1] != directions[-2] and directions[-2] != 0: phase = "correction"
        rejection = (recent[-1].low < recent[-2].low and recent[-1].close > recent[-1].open and
                     recent[-1].close > (recent[-1].high + recent[-1].low) / 2)
        recovery = directions[-1] > 0 and directions[-2] <= 0 and bodies[-1] > abs(bodies[-2])
        exhaustion = (abs(bodies[-1]) < abs(bodies[-2]) * 0.5 and 
                      directions[-1] == directions[-2] and directions[-1] != 0)
        breakout = recent[-1].high > max(c.high for c in recent[:-1]) if len(recent) > 1 else False
        failed_breakout = breakout and recent[-1].close < recent[-1].open
        desc = f"Current phase: {phase}. "
        if rejection: desc += "Rejection of lower prices detected. "
        if recovery: desc += "Recovery sequence starting. "
        if exhaustion: desc += "Possible exhaustion. "
        return SequenceState(
            current_phase=phase, previous_phases=[],
            impulse_detected=phase=="impulse", correction_detected=phase=="correction",
            pullback_detected=phase=="correction" and directions[-2]>0,
            rejection_detected=rejection, recovery_detected=recovery,
            momentum_loss=exhaustion, exhaustion_detected=exhaustion,
            consolidation=phase=="consolidation", compression=False,
            breakout_detected=breakout, failed_breakout=failed_breakout,
            retest_detected=False, continuation_likely=phase=="impulse" and not exhaustion,
            reversal_candidate=rejection and phase=="decline",
            transition_detected=phase != "consolidation" and len(recent) > 5,
            description=desc
        )

    def _build_structure(self, candles: List[CanonicalCandle], index: int) -> MarketStructure:
        window = candles[max(0, index-20):index+1]
        swings_high = []
        swings_low = []
        for i in range(2, len(window)-2):
            if window[i].high > window[i-1].high and window[i].high > window[i-2].high and                window[i].high > window[i+1].high and window[i].high > window[i+2].high:
                swings_high.append((window[i].timestamp, window[i].high))
            if window[i].low < window[i-1].low and window[i].low < window[i-2].low and                window[i].low < window[i+1].low and window[i].low < window[i+2].low:
                swings_low.append((window[i].timestamp, window[i].low))
        hh = len(swings_high) >= 2 and swings_high[-1][1] > swings_high[-2][1]
        hl = len(swings_low) >= 2 and swings_low[-1][1] > swings_low[-2][1]
        lh = len(swings_high) >= 2 and swings_high[-1][1] < swings_high[-2][1]
        ll = len(swings_low) >= 2 and swings_low[-1][1] < swings_low[-2][1]
        trend = "undefined"
        if hh and hl: trend = "bullish"
        elif lh and ll: trend = "bearish"
        return MarketStructure(
            swing_highs=swings_high[-5:], swing_lows=swings_low[-5:],
            higher_highs=hh, higher_lows=hl, lower_highs=lh, lower_lows=ll,
            trend=trend, range_state=not (hh or hl or lh or ll),
            bos_detected=False, choch_detected=False,
            structural_failure=False, structural_transition=False,
            continuation_likely=trend!="undefined", reversal_candidate=False
        )

    def _build_support_resistance(self, candles: List[CanonicalCandle], index: int) -> List[SupportResistanceArea]:
        window = candles[max(0, index-30):index+1]
        areas = []
        for i in range(3, len(window)-3):
            if window[i].high > max(c.high for c in window[i-3:i]) and                window[i].high > max(c.high for c in window[i+1:i+4]):
                areas.append(SupportResistanceArea(
                    price_low=window[i].high * 0.998,
                    price_high=window[i].high * 1.002,
                    creation_reason="local_high",
                    num_tests=1, reaction_strength=0.5,
                    freshness=1.0 - (index - i) / 30,
                    is_broken=window[-1].close > window[i].high,
                    is_retested=abs(window[-1].close - window[i].high) / window[i].high < 0.005,
                    is_failed=False, role_reversal=False
                ))
        return areas[-5:]

    def _build_momentum(self, candles: List[CanonicalCandle], index: int) -> MomentumState:
        recent = candles[max(0, index-10):index+1]
        if len(recent) < 5:
            return MomentumState(False, False, False, False, 0, False, False, False)
        returns = [(recent[i].close/recent[i-1].close - 1) for i in range(1, len(recent))]
        increasing = returns[-1] > returns[-2] if len(returns) >= 2 else False
        decreasing = returns[-1] < returns[-2] if len(returns) >= 2 else False
        accel = returns[-1] > returns[-2] > 0 if len(returns) >= 2 else False
        exhausted = abs(returns[-1]) < abs(returns[-2]) * 0.3 if len(returns) >= 2 else False
        strength = abs(sum(returns[-3:])) if len(returns) >= 3 else 0
        return MomentumState(
            momentum_increasing=increasing, momentum_decreasing=decreasing,
            accelerating=accel, exhausted=exhausted,
            directional_strength=strength,
            follow_through=increasing and returns[-1] > 0,
            failed_push=returns[-1] > 0 and returns[-1] < returns[-2],
            momentum_disagreement=False
        )

    def _build_regime(self, candles: List[CanonicalCandle], index: int) -> RegimeState:
        recent = candles[max(0, index-20):index+1]
        if len(recent) < 20:
            return RegimeState(False, False, False, False, False, False, False, False, False)
        returns = [(recent[i].close/recent[i-1].close - 1) for i in range(1, len(recent))]
        vol = math.sqrt(sum(r*r for r in returns) / len(returns)) if returns else 0
        prev_returns = [(candles[max(0, index-40)].close/candles[max(0, index-41)].close - 1)] if index >= 41 else [0]
        prev_vol = abs(prev_returns[0]) if prev_returns else 0
        trending = abs(sum(returns)) > vol * 3
        ranging = not trending
        high_vol = vol > 0.005
        low_vol = vol < 0.002
        vol_expanding = vol > prev_vol * 1.5
        vol_contracting = vol < prev_vol * 0.7
        label = "ranging"
        if trending and high_vol: label = "trending_volatile"
        elif trending: label = "trending_quiet"
        elif high_vol: label = "ranging_volatile"
        elif low_vol: label = "ranging_quiet"
        elif vol_expanding: label = "transition_expanding"
        elif vol_contracting: label = "transition_contracting"
        return RegimeState(
            trending=trending, ranging=ranging,
            high_volatility=high_vol, low_volatility=low_vol,
            volatility_expanding=vol_expanding,
            volatility_contracting=vol_contracting,
            transitioning=vol_expanding or vol_contracting,
            strong_directional=trending and high_vol,
            weak_directional=ranging and low_vol,
            regime_label=label
        )

    def _build_context(self, current: CanonicalCandle, structure: MarketStructure, 
                       regime: RegimeState, candles: List[CanonicalCandle], index: int) -> ContextState:
        location = "middle"
        recent = candles[max(0, index-20):index+1]
        if recent:
            r_high = max(c.high for c in recent)
            r_low = min(c.low for c in recent)
            pos = (current.close - r_low) / (r_high - r_low) if r_high != r_low else 0.5
            if pos > 0.8: location = "upper_range"
            elif pos < 0.2: location = "lower_range"
            elif pos > 0.6: location = "upper_middle"
            elif pos < 0.4: location = "lower_middle"
        prev_move = "neutral"
        if index > 5:
            change = (current.close - candles[index-5].close) / candles[index-5].close
            if change > 0.01: prev_move = "strong_up"
            elif change > 0: prev_move = "up"
            elif change > -0.01: prev_move = "down"
            else: prev_move = "strong_down"
        return ContextState(
            instrument=current.instrument if hasattr(current, 'instrument') else "unknown",
            timeframe=current.timeframe if hasattr(current, 'timeframe') else "unknown",
            session="unknown",
            trend_context=structure.trend,
            range_context="ranging" if regime.ranging else "trending",
            location=location,
            previous_movement=prev_move,
            structure_state=structure.trend,
            volatility_state="high" if regime.high_volatility else "low" if regime.low_volatility else "normal",
            momentum_state="strong" if regime.strong_directional else "weak",
            volume_available=current.volume > 0,
            recent_reactions=[],
            htf_context=None
        )


# ============================================================================
# SECTION 5: TARGET & OUTCOME SYSTEM (Phase P1)
# ============================================================================

@dataclass
class OutcomeLabel:
    direction: str
    return_pct: float
    atr_normalized_return: float
    mfe: float
    mae: float
    time_to_mfe: int
    time_to_mae: int
    structural_events: List[str]
    horizon: int

    @classmethod
    def generate(cls, candles: List[CanonicalCandle], index: int, horizon: int, atr: float) -> 'OutcomeLabel':
        if index + horizon >= len(candles):
            return cls("unknown", 0, 0, 0, 0, 0, 0, [], horizon)
        start = candles[index].close
        future = candles[index+1:index+horizon+1]
        end_price = candles[index+horizon].close
        return_pct = (end_price / start - 1) if start != 0 else 0
        highs = [c.high for c in future]
        lows = [c.low for c in future]
        mfe = (max(highs) / start - 1) if start != 0 else 0
        mae = (min(lows) / start - 1) if start != 0 else 0
        atr_norm = return_pct / atr if atr > 0 else 0
        threshold = 0.0015
        if return_pct >= threshold: direction = "higher"
        elif return_pct <= -threshold: direction = "lower"
        else: direction = "neutral"
        events = []
        if any(c.low < candles[index].low for c in future):
            events.append("support_tested")
        if any(c.high > candles[index].high for c in future):
            events.append("resistance_tested")
        return cls(direction, return_pct, atr_norm, mfe, mae, 0, 0, events, horizon)


# ============================================================================
# SECTION 6: HISTORICAL EXPERIENCE MEMORY (Phase P1)
# ============================================================================

class MemoryQuality(Enum):
    CANDIDATE = "candidate"
    UNDER_EVALUATION = "under_evaluation"
    VALIDATED = "validated"
    WEAK_EVIDENCE = "weak_evidence"
    FAILED = "failed"
    DEPRECATED = "deprecated"

@dataclass
class ExperienceRecord:
    id: str
    instrument: str
    timeframe: str
    timestamp: int
    market_state: MarketState
    regime: str
    outcome: OutcomeLabel
    sample_count: int = 1
    success_count: int = 0
    failure_count: int = 0
    confidence_interval: Tuple[float, float] = (0.0, 1.0)
    quality: MemoryQuality = MemoryQuality.CANDIDATE
    dataset_version: str = "v1"
    feature_version: str = "v1"
    last_verified: str = ""

    def update_verification(self, success: bool):
        if success:
            self.success_count += 1
        else:
            self.failure_count += 1
        total = self.success_count + self.failure_count
        if total > 0:
            rate = self.success_count / total
            z = 1.96
            ci = z * math.sqrt(rate * (1 - rate) / total) if total > 0 else 0.5
            self.confidence_interval = (max(0, rate - ci), min(1, rate + ci))

class ExperienceMemory:
    def __init__(self, storage_path: str = "mlai_memory.pkl"):
        self.storage_path = storage_path
        self.records: List[ExperienceRecord] = []
        self._index_by_regime: Dict[str, List[int]] = defaultdict(list)
        self._index_by_feature: Dict[str, Dict[Any, List[int]]] = defaultdict(lambda: defaultdict(list))
        self._load()

    def _load(self):
        if os.path.exists(self.storage_path):
            with open(self.storage_path, 'rb') as f:
                data = pickle.load(f)
                self.records = data.get('records', [])
                self._rebuild_indices()

    def _rebuild_indices(self):
        self._index_by_regime.clear()
        self._index_by_feature.clear()
        for idx, rec in enumerate(self.records):
            self._index_by_regime[rec.regime].append(idx)
            features = rec.market_state.to_feature_vector()
            for k, v in features.items():
                self._index_by_feature[k][v].append(idx)

    def store(self, record: ExperienceRecord):
        self.records.append(record)
        idx = len(self.records) - 1
        self._index_by_regime[record.regime].append(idx)
        features = record.market_state.to_feature_vector()
        for k, v in features.items():
            self._index_by_feature[k][v].append(idx)

    def query_by_regime(self, regime: str, min_quality: MemoryQuality = MemoryQuality.CANDIDATE) -> List[ExperienceRecord]:
        result = []
        for idx in self._index_by_regime.get(regime, []):
            rec = self.records[idx]
            if self._quality_rank(rec.quality) >= self._quality_rank(min_quality):
                result.append(rec)
        return result

    def _quality_rank(self, q: MemoryQuality) -> int:
        ranks = {MemoryQuality.CANDIDATE: 0, MemoryQuality.UNDER_EVALUATION: 1,
                 MemoryQuality.WEAK_EVIDENCE: 2, MemoryQuality.VALIDATED: 3,
                 MemoryQuality.FAILED: -1, MemoryQuality.DEPRECATED: -2}
        return ranks.get(q, 0)

    def save(self):
        with open(self.storage_path, 'wb') as f:
            pickle.dump({'records': self.records, 'saved_at': datetime.now(timezone.utc).isoformat()}, f)

    def get_statistics(self) -> Dict:
        total = len(self.records)
        by_quality = Counter(r.quality.value for r in self.records)
        by_regime = Counter(r.regime for r in self.records)
        return {"total_records": total, "by_quality": dict(by_quality),
                "by_regime": dict(by_regime),
                "validated_outcomes": sum(1 for r in self.records if r.quality == MemoryQuality.VALIDATED)}


# ============================================================================
# SECTION 7: SIMILARITY RETRIEVAL (Phase P1/P2)
# ============================================================================

class SimilarityEngine:
    def __init__(self, memory: ExperienceMemory):
        self.memory = memory
        self.weights = {
            "regime": 2.0, "sequence_phase": 1.5, "trend": 1.5,
            "location": 1.0, "direction": 0.8, "momentum": 1.0,
            "volatility": 0.8, "structure": 1.2
        }

    def find_similar(self, current_state: MarketState, 
                     max_matches: int = 50,
                     min_similarity: float = 0.5) -> List[Tuple[ExperienceRecord, float]]:
        current_features = current_state.to_feature_vector()
        candidates = []
        regime_matches = self.memory.query_by_regime(current_state.regime.regime_label)
        for record in regime_matches:
            sim = self._calculate_similarity(current_features, record.market_state.to_feature_vector())
            if sim >= min_similarity:
                candidates.append((record, sim))
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[:max_matches]

    def _calculate_similarity(self, f1: Dict, f2: Dict) -> float:
        score = 0.0
        total_weight = 0.0
        for feature, weight in self.weights.items():
            v1 = f1.get(feature)
            v2 = f2.get(feature)
            if v1 is None or v2 is None:
                continue
            total_weight += weight
            if v1 == v2:
                score += weight
            elif isinstance(v1, (int, float)) and isinstance(v2, (int, float)):
                diff = abs(v1 - v2)
                sim = max(0, 1 - diff)
                score += weight * sim
        return score / total_weight if total_weight > 0 else 0

    def aggregate_outcomes(self, matches: List[Tuple[ExperienceRecord, float]]) -> Dict:
        if not matches:
            return {"higher": 0.0, "lower": 0.0, "neutral": 0.0,
                    "sample_count": 0, "avg_similarity": 0.0, "sparse_warning": True}
        weighted_counts = Counter()
        total_weight = 0.0
        for record, sim in matches:
            w = sim * record.sample_count
            weighted_counts[record.outcome.direction] += w
            total_weight += w
        if total_weight == 0:
            return {"higher": 0.0, "lower": 0.0, "neutral": 0.0, "sample_count": 0, "sparse_warning": True}
        return {
            "higher": weighted_counts.get("higher", 0) / total_weight,
            "lower": weighted_counts.get("lower", 0) / total_weight,
            "neutral": weighted_counts.get("neutral", 0) / total_weight,
            "sample_count": len(matches),
            "avg_similarity": sum(s for _, s in matches) / len(matches),
            "sparse_warning": len(matches) < 10
        }


# ============================================================================
# SECTION 8: PROBABILITY & CALIBRATION (Phase P1/P2)
# ============================================================================

class ProbabilityEngine:
    def __init__(self):
        self.calibration_data: List[Tuple[float, bool]] = []

    def calculate_probabilities(self, outcome_distribution: Dict, 
                                sample_count: int,
                                similarity_strength: float) -> Dict:
        alpha = 1.0
        smoothed = {}
        total = sample_count + 3 * alpha
        for direction in ["higher", "lower", "neutral"]:
            raw = outcome_distribution.get(direction, 0) * sample_count
            smoothed[direction] = (raw + alpha) / total
        confidence = min(1.0, similarity_strength * sample_count / 50)
        if sample_count < 20:
            baseline = 1/3
            for k in smoothed:
                smoothed[k] = smoothed[k] * confidence + baseline * (1 - confidence)
        total_prob = sum(smoothed.values())
        if total_prob > 0:
            smoothed = {k: v/total_prob for k, v in smoothed.items()}
        cal_status = "good" if sample_count > 100 and confidence > 0.7 else                      "acceptable" if sample_count > 30 else "uncertain"
        return {
            "probabilities": smoothed,
            "confidence": confidence,
            "sample_count": sample_count,
            "calibration_status": cal_status,
            "sparse_data_warning": sample_count < 10
        }

    def brier_score(self) -> float:
        if not self.calibration_data:
            return 0.0
        return sum((p - (1 if a else 0))**2 for p, a in self.calibration_data) / len(self.calibration_data)

    def record_calibration(self, predicted_prob: float, actual: bool):
        self.calibration_data.append((predicted_prob, actual))


# ============================================================================
# SECTION 9: SCENARIO REASONING (Phase P2)
# ============================================================================

@dataclass
class Scenario:
    name: str
    direction: str
    supporting_evidence: List[str]
    contradicting_evidence: List[str]
    historical_probability: float
    confidence: float
    confirmation_conditions: List[str]
    invalidation_conditions: List[str]
    expected_path: str
    time_horizon: str
    missing_evidence: List[str]

class ScenarioEngine:
    def __init__(self, causality: CausalityRegistry):
        self.causality = causality

    def generate_scenarios(self, state: MarketState, 
                          probabilities: Dict,
                          similar_cases: List[Tuple[ExperienceRecord, float]]) -> List[Scenario]:
        scenarios = []
        # Scenario 1: Recovery Continuation
        if state.sequence.recovery_detected or state.sequence.rejection_detected:
            sup = []
            con = []
            if state.sequence.rejection_detected:
                sup.append("Rejection of lower prices detected")
            if state.momentum.momentum_increasing:
                sup.append("Improving short-term momentum")
            if state.context.location in ["lower_range", "lower_middle"]:
                sup.append("Price near support area")
            if state.structure.trend == "bearish":
                con.append("Larger structure remains bearish")
            if not state.momentum.follow_through:
                con.append("Bullish follow-through is weak")
            scenarios.append(Scenario(
                name="Recovery Continuation", direction="higher",
                supporting_evidence=sup, contradicting_evidence=con,
                historical_probability=probabilities.get("higher", 0.33),
                confidence=probabilities.get("confidence", 0.5),
                confirmation_conditions=["Sustained break above recent swing high", "Close above resistance with volume"],
                invalidation_conditions=["Close below recent support", "Failed breakout with reversal candle"],
                expected_path="Gradual recovery toward recent resistance",
                time_horizon="short_term",
                missing_evidence=["Higher-timeframe confirmation"] if not state.context.htf_context else []
            ))
        # Scenario 2: Bearish Continuation
        if state.structure.trend == "bearish" or (state.regime.trending and state.structure.lower_lows):
            sup = []
            con = []
            if state.structure.trend == "bearish":
                sup.append("Larger structure remains bearish")
            if state.context.location in ["upper_range", "upper_middle"]:
                sup.append("Price at resistance in bearish structure")
            if state.momentum.exhausted and state.sequence.current_phase == "impulse":
                sup.append("Momentum exhaustion in bearish move")
            if state.sequence.recovery_detected:
                con.append("Short-term recovery is underway")
            if state.sequence.rejection_detected:
                con.append("Lower prices being rejected")
            scenarios.append(Scenario(
                name="Bearish Continuation", direction="lower",
                supporting_evidence=sup, contradicting_evidence=con,
                historical_probability=probabilities.get("lower", 0.33),
                confidence=probabilities.get("confidence", 0.5) * 0.8,
                confirmation_conditions=["Rejection at resistance", "Break below recent support"],
                invalidation_conditions=["Strong close above structural resistance", "Sustained recovery"],
                expected_path="Decline toward next support level",
                time_horizon="medium_term",
                missing_evidence=[]
            ))
        # Scenario 3: Range Continuation
        if state.regime.ranging or state.sequence.consolidation:
            sup = []
            con = []
            if state.regime.ranging:
                sup.append("Mixed structure with no clear direction")
            if state.momentum.directional_strength < 0.01:
                sup.append("Low directional strength")
            if state.sequence.consolidation:
                sup.append("Repeated reversals near boundaries")
            if state.sequence.breakout_detected:
                con.append("Potential breakout detected")
            if state.momentum.accelerating:
                con.append("Momentum is building")
            scenarios.append(Scenario(
                name="Range Continuation", direction="neutral",
                supporting_evidence=sup, contradicting_evidence=con,
                historical_probability=probabilities.get("neutral", 0.33),
                confidence=probabilities.get("confidence", 0.5) * 0.9,
                confirmation_conditions=["Continued rejection from range edges", "Compression near center"],
                invalidation_conditions=["Sustained range breakout", "Strong directional close"],
                expected_path="Price oscillates within established range",
                time_horizon="short_term",
                missing_evidence=[]
            ))
        scenarios.sort(key=lambda s: s.confidence, reverse=True)
        return scenarios


# ============================================================================
# SECTION 10: EXPLANATION GENERATION (Phase P2)
# ============================================================================

class ExplanationGenerator:
    def generate(self, state: MarketState, 
                scenarios: List[Scenario],
                probabilities: Dict,
                similar_count: int,
                conflicting: List[str]) -> str:
        lines = []
        ca = state.candle_anatomy
        lines.append(f"Current Observation: {ca.direction} candle with body/range ratio {ca.body_range_ratio:.2f}. "
                    f"{'Expansion' if ca.is_expansion else 'Compression' if ca.is_compression else 'Normal size'} detected. "
                    f"Price located in {state.context.location.replace('_', ' ')}.")
        if state.sequence.description:
            lines.append(f"Recent Change: {state.sequence.description}")
        st = state.structure
        lines.append(f"Market Structure: {st.trend} trend. "
                    f"{'Higher highs and higher lows' if st.higher_highs and st.higher_lows else ''}"
                    f"{'Lower highs and lower lows' if st.lower_highs and st.lower_lows else ''}"
                    f"{'No clear structure' if not (st.higher_highs or st.lower_lows) else ''}.")
        lines.append(f"Context: {state.regime.regime_label.replace('_', ' ')} regime. "
                    f"Volatility is {'high' if state.regime.high_volatility else 'low' if state.regime.low_volatility else 'normal'}. "
                    f"Momentum is {'increasing' if state.momentum.momentum_increasing else 'decreasing' if state.momentum.momentum_decreasing else 'stable'}.")
        lines.append(f"Historical Evidence: {similar_count} comparable situations found. "
                    f"Calibration status: {probabilities.get('calibration_status', 'unknown')}.")
        probs = probabilities.get('probabilities', {})
        lines.append(f"Outcome Probabilities: Higher {probs.get('higher', 0):.1%}, "
                    f"Lower {probs.get('lower', 0):.1%}, Neutral {probs.get('neutral', 0):.1%}.")
        if probabilities.get('sparse_data_warning'):
            lines.append("WARNING: Sparse historical evidence. Confidence is reduced.")
        lines.append("\nLeading Scenarios:")
        for i, sc in enumerate(scenarios[:3], 1):
            lines.append(f"\n{i}. {sc.name} (confidence: {sc.confidence:.0%})")
            lines.append(f"   Supporting: {'; '.join(sc.supporting_evidence) if sc.supporting_evidence else 'Limited direct evidence'}")
            if sc.contradicting_evidence:
                lines.append(f"   Contradicting: {'; '.join(sc.contradicting_evidence)}")
            lines.append(f"   Confirmation: {'; '.join(sc.confirmation_conditions)}")
            lines.append(f"   Invalidation: {'; '.join(sc.invalidation_conditions)}")
        if conflicting:
            lines.append(f"\nConflicting Evidence: {'; '.join(conflicting)}")
        missing = []
        if not state.context.volume_available:
            missing.append("Volume data")
        if not state.context.htf_context:
            missing.append("Higher-timeframe context")
        if missing:
            lines.append(f"\nUnavailable Information: {', '.join(missing)}")
        lines.append("\nNote: This is evidence-based interpretation, not certainty. "
                    "Historical repetition increases or decreases evidence but does not guarantee repetition.")
        return "\n".join(lines)


# ============================================================================
# SECTION 11: VALIDATION FRAMEWORK (Phase P0/P1)
# ============================================================================

class ChronologicalSplit:
    def __init__(self, candles: List[CanonicalCandle], 
                 train_end: int, validation_end: int,
                 purge_horizon: int = 16):
        self.candles = candles
        self.train_end = train_end
        self.validation_end = validation_end
        self.purge_horizon = purge_horizon
        self.train_indices = []
        for i in range(train_end - purge_horizon):
            if i + purge_horizon < train_end:
                self.train_indices.append(i)
        self.validation_indices = list(range(train_end, validation_end))
        self.test_indices = list(range(validation_end, len(candles) - purge_horizon))

    def get_train(self) -> List[CanonicalCandle]:
        return [self.candles[i] for i in self.train_indices]

    def get_validation(self) -> List[CanonicalCandle]:
        return [self.candles[i] for i in self.validation_indices]

    def get_test(self) -> List[CanonicalCandle]:
        return [self.candles[i] for i in self.test_indices]

class WalkForwardValidator:
    def __init__(self, n_folds: int = 4, min_train: int = 100, 
                 horizons: List[int] = None, purge: int = 16):
        self.n_folds = n_folds
        self.min_train = min_train
        self.horizons = horizons or [4, 8, 16]
        self.purge = purge
        self.results: List[Dict] = []

    def create_folds(self, candles: List[CanonicalCandle]) -> List[ChronologicalSplit]:
        if len(candles) < self.min_train * 2:
            return []
        usable = len(candles) - max(self.horizons) - self.purge
        fold_size = (usable - self.min_train) // self.n_folds
        splits = []
        for fold in range(self.n_folds):
            train_end = self.min_train + fold * fold_size
            val_end = train_end + fold_size
            if val_end < usable:
                splits.append(ChronologicalSplit(candles, train_end, val_end, self.purge))
        return splits

    def run_null_test(self, candles: List[CanonicalCandle], 
                     build_state_fn: Callable,
                     label_fn: Callable,
                     n_permutations: int = 25,
                     seed: int = 42) -> Dict:
        rng = random.Random(seed)
        states = []
        labels = []
        for i in range(self.min_train, len(candles) - max(self.horizons)):
            state = build_state_fn(candles, i)
            if state:
                label = label_fn(candles, i, self.horizons[0])
                states.append(state)
                labels.append(label.direction)
        majority = Counter(labels).most_common(1)[0][0]
        baseline_acc = sum(1 for l in labels if l == majority) / len(labels)
        null_accuracies = []
        for _ in range(n_permutations):
            shuffled = labels.copy()
            rng.shuffle(shuffled)
            pred = Counter(shuffled).most_common(1)[0][0]
            acc = sum(1 for l in shuffled if l == pred) / len(shuffled)
            null_accuracies.append(acc)
        return {
            "baseline_accuracy": baseline_acc,
            "mean_null_accuracy": sum(null_accuracies) / len(null_accuracies),
            "max_null_accuracy": max(null_accuracies),
            "n_permutations": n_permutations,
            "interpretation": "If null accuracies approach real accuracy, results may be spurious."
        }


# ============================================================================
# SECTION 12: MLAI MARKET LANGUAGE BRAIN — ORCHESTRATOR
# ============================================================================

class MLAIMarketLanguageBrain:
    def __init__(self, storage_dir: str = "mlai_data"):
        self.storage_dir = storage_dir
        os.makedirs(storage_dir, exist_ok=True)
        self.causality = CausalityRegistry()
        self.data_store = ImmutableDataStore(os.path.join(storage_dir, "raw_data.pkl"))
        self.state_builder = MarketStateBuilder(self.causality)
        self.memory = ExperienceMemory(os.path.join(storage_dir, "experience_memory.pkl"))
        self.similarity = SimilarityEngine(self.memory)
        self.probability = ProbabilityEngine()
        self.scenario_engine = ScenarioEngine(self.causality)
        self.explainer = ExplanationGenerator()
        self.validator = WalkForwardValidator()
        self._candles: List[CanonicalCandle] = []
        self._states: List[Optional[MarketState]] = []

    def ingest_candles(self, raw_candles: List[RawCandle]) -> DataQualityReport:
        report = DataQualityReport()
        for candle in raw_candles:
            report.total_records += 1
            try:
                if self.data_store.append(candle):
                    report.accepted += 1
                else:
                    report.duplicate_timestamps += 1
            except ValueError:
                report.invalid_ohlc += 1
                report.rejected += 1
        self.data_store.save()
        return report

    def load_instrument(self, instrument: str, timeframe: str) -> bool:
        raw = self.data_store.get_instrument_data(instrument, timeframe)
        if not raw:
            return False
        self._candles = [c.to_canonical() for c in sorted(raw, key=lambda x: x.timestamp)]
        self._states = [None] * len(self._candles)
        for i in range(len(self._candles)):
            self._states[i] = self.state_builder.build_state(self._candles, i)
        return True

    def build_experience_memory(self, instrument: str, timeframe: str, 
                                horizons: List[int] = None) -> Dict:
        horizons = horizons or [4, 8, 16]
        if not self._candles:
            if not self.load_instrument(instrument, timeframe):
                return {"error": "No data loaded"}
        added = 0
        for i in range(len(self._candles)):
            state = self._states[i]
            if not state:
                continue
            atr = self.state_builder._calculate_atr(self._candles, i)
            for h in horizons:
                if i + h >= len(self._candles):
                    continue
                label = OutcomeLabel.generate(self._candles, i, h, atr)
                record = ExperienceRecord(
                    id=f"{instrument}_{timeframe}_{i}_{h}",
                    instrument=instrument, timeframe=timeframe,
                    timestamp=self._candles[i].timestamp,
                    market_state=state, regime=state.regime.regime_label,
                    outcome=label, sample_count=1,
                    last_verified=datetime.now(timezone.utc).isoformat()
                )
                self.memory.store(record)
                added += 1
        self.memory.save()
        return {"records_added": added, "memory_stats": self.memory.get_statistics()}

    def analyze_current(self, index: int = -1) -> Dict:
        if not self._states or not self._states[index]:
            return {"error": "No state available"}
        state = self._states[index]
        similar = self.similarity.find_similar(state, max_matches=50)
        outcomes = self.similarity.aggregate_outcomes(similar)
        probs = self.probability.calculate_probabilities(
            outcomes, outcomes["sample_count"], outcomes["avg_similarity"]
        )
        scenarios = self.scenario_engine.generate_scenarios(state, probs, similar)
        conflicting = []
        if state.sequence.rejection_detected and state.structure.trend == "bearish":
            conflicting.append("Short-term rejection vs bearish structure")
        if state.momentum.momentum_increasing and state.momentum.exhausted:
            conflicting.append("Momentum increase vs exhaustion signals")
        explanation = self.explainer.generate(
            state, scenarios, probs, outcomes["sample_count"], conflicting
        )
        return {
            "market_state": state,
            "similar_cases": len(similar),
            "outcome_distribution": outcomes,
            "probabilities": probs,
            "scenarios": scenarios,
            "explanation": explanation,
            "conflicting_evidence": conflicting
        }

    def run_validation(self, instrument: str, timeframe: str) -> Dict:
        if not self.load_instrument(instrument, timeframe):
            return {"error": "No data"}
        def build_fn(candles, idx):
            return self.state_builder.build_state(candles, idx)
        def label_fn(candles, idx, h):
            atr = self.state_builder._calculate_atr(candles, idx)
            return OutcomeLabel.generate(candles, idx, h, atr)
        null_result = self.validator.run_null_test(
            self._candles, build_fn, label_fn, n_permutations=25
        )
        splits = self.validator.create_folds(self._candles)
        return {
            "null_test": null_result,
            "n_folds": len(splits),
            "data_points": len(self._candles),
            "validation_ready": len(splits) > 0
        }

    def get_project_status(self) -> Dict:
        return {
            "data_store": {"total_raw_candles": len(self.data_store.raw_candles), "protected": True},
            "memory": self.memory.get_statistics(),
            "causality_registry": {"registered_features": len(self.causality._registry), "protected": True},
            "loaded_candles": len(self._candles),
            "loaded_states": sum(1 for s in self._states if s is not None),
            "phases_implemented": ["P0", "P1", "P2_foundation"],
            "validation": "Walk-forward with purging and null testing"
        }


# ============================================================================
# SECTION 13: DEMONSTRATION
# ============================================================================

def create_demo_data(n: int = 500, instrument: str = "XAUUSD", timeframe: str = "1H") -> List[RawCandle]:
    random.seed(42)
    candles = []
    price = 1800.0
    timestamp = 1609459200
    for i in range(n):
        change = random.gauss(0.0002 if i < n//2 else -0.0002, 0.003)
        if i > n//2 and i % 20 == 0:
            change += random.gauss(0, 0.01)
        open_p = price
        close_p = price * (1 + change)
        high_p = max(open_p, close_p) * (1 + abs(random.gauss(0, 0.002)))
        low_p = min(open_p, close_p) * (1 - abs(random.gauss(0, 0.002)))
        vol = abs(random.gauss(1000, 200))
        candle = RawCandle(
            instrument=instrument, timeframe=timeframe,
            timestamp=timestamp + i * 3600,
            open=round(open_p, 2), high=round(high_p, 2),
            low=round(low_p, 2), close=round(close_p, 2),
            volume=round(vol, 2), source="demo",
            retrieved_at=datetime.now(timezone.utc).isoformat()
        )
        candles.append(candle)
        price = close_p
    return candles


def main():
    print("=" * 78)
    print("MLAI MARKET LANGUAGE BRAIN — DEMONSTRATION")
    print("=" * 78)
    print()
    brain = MLAIMarketLanguageBrain(storage_dir="mlai_brain_demo")
    print("[1] System initialized")
    print(f"    Causality registry: {len(brain.causality._registry)} features registered")
    print(f"    Data store: PROTECTED (append-only, hashed)")
    print(f"    Memory: versioned with quality tracking")
    print()
    print("[2] Generating synthetic market data (XAUUSD 1H, 500 candles)...")
    raw_candles = create_demo_data(500)
    report = brain.ingest_candles(raw_candles)
    print(f"    Total: {report.total_records}, Accepted: {report.accepted}, Rejected: {report.rejected}")
    print(f"    Invalid OHLC: {report.invalid_ohlc}, Duplicates: {report.duplicate_timestamps}")
    print()
    print("[3] Loading instrument data...")
    success = brain.load_instrument("XAUUSD", "1H")
    print(f"    Loaded: {success}, Candles: {len(brain._candles)}, States built: {sum(1 for s in brain._states if s)}")
    print()
    print("[4] Building historical experience memory...")
    mem_result = brain.build_experience_memory("XAUUSD", "1H", horizons=[4, 8, 16])
    print(f"    Records added: {mem_result['records_added']}")
    stats = mem_result['memory_stats']
    print(f"    Memory stats: {stats}")
    print()
    print("[5] Analyzing current market state...")
    analysis = brain.analyze_current(index=-1)
    print(f"    Similar cases found: {analysis['similar_cases']}")
    print(f"    Sparse warning: {analysis['outcome_distribution'].get('sparse_warning', False)}")
    print()
    print("[6] GENERATED EXPLANATION:")
    print("-" * 78)
    print(analysis['explanation'])
    print("-" * 78)
    print()
    print("[7] Running validation diagnostics...")
    val_result = brain.run_validation("XAUUSD", "1H")
    print(f"    Null test baseline: {val_result['null_test']['baseline_accuracy']:.2%}")
    print(f"    Mean null accuracy: {val_result['null_test']['mean_null_accuracy']:.2%}")
    print(f"    Max null accuracy: {val_result['null_test']['max_null_accuracy']:.2%}")
    print(f"    Folds available: {val_result['n_folds']}")
    print()
    print("[8] PROJECT STATUS:")
    status = brain.get_project_status()
    print(f"    Raw candles protected: {status['data_store']['protected']}")
    print(f"    Memory records: {status['memory']['total_records']}")
    print(f"    Phases implemented: {', '.join(status['phases_implemented'])}")
    print()
    print("=" * 78)
    print("DEMONSTRATION COMPLETE")
    print("=" * 78)
    print()
    print("Next steps:")
    print("  - Replace synthetic data with real OHLCV feeds")
    print("  - Expand similarity engine with more nuanced distance metrics")
    print("  - Implement multi-timeframe reasoning (Phase P2)")
    print("  - Add live data pipeline with controlled learning (Phase P3)")
    print()
    return brain, analysis


if __name__ == "__main__":
    brain, analysis = main()