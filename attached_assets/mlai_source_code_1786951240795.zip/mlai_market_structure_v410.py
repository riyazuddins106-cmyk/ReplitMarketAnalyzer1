"""
================================================================================
MLAI v4.1.0 ROBUST CAUSAL PREDICTIVE MARKET STRUCTURE INTELLIGENCE
================================================================================

RESEARCH / VALIDATION ONLY

Purpose
-------
This file is a complete replacement for mlai_market_structure_v400.py.

It keeps the causal/walk-forward discipline of v4.0 and adds a real predictive
learning layer:

    causal market structure
        +
    causal price / volatility context
        +
    hierarchical state statistics
        +
    regularized logistic model
        +
    frozen walk-forward kNN model
        +
    conservative ensemble
        +
    abstention / confidence
        +
    calibration diagnostics
        +
    untouched chronological OOS validation

IMPORTANT
---------
This is NOT a claim that the market is predictable. The program is designed to
find out whether the supplied data contains stable predictive information.

No OOS observation is used to fit, scale, encode, calibrate, or select a model.
market_data.bin is read-only and is hash checked before/after execution.
No production MLAI memory is modified. Trading is disabled.

Dependencies: Python standard library only.
================================================================================
"""

from __future__ import annotations

import hashlib
import math
import os
import pickle
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


# ==============================================================================
# CONFIGURATION
# ==============================================================================

VERSION = "4.1.0"

MARKET_DATA_FILE = "market_data.bin"

VALIDATION_BIN = "MLAI_V410_ROBUST_PREDICTIVE_WALKFORWARD_VALIDATION.bin"
VALIDATION_REPORT = "MLAI_V410_ROBUST_PREDICTIVE_WALKFORWARD_VALIDATION_REPORT.md"

HORIZONS = (4, 8, 16)

SWING_LEFT = 3
SWING_RIGHT = 3

DEFAULT_TRAIN_WINDOWS = 5
DEFAULT_OOS_SIZE = 81

MIN_TRAIN_SAMPLES = 120
MIN_STATE_SUPPORT = 8

LOGISTIC_EPOCHS = 500
LOGISTIC_LR = 0.035
LOGISTIC_L2 = 0.75

KNN_K = 25
KNN_TEMPERATURE = 1.25

STATE_PRIOR_STRENGTH = 20.0

# Fixed ensemble weights. They are deliberately NOT optimized on OOS data.
WEIGHT_LOGISTIC = 0.55
WEIGHT_KNN = 0.25
WEIGHT_STATE = 0.20

# Abstention policy. These constants are fixed before validation.
MIN_CONFIDENCE = 0.57
MIN_SUPPORT_FOR_FULL_CONFIDENCE = 20
MIN_MARGIN = 0.075

EPS = 1e-12


# ==============================================================================
# BASIC DATA TYPES
# ==============================================================================

@dataclass
class Candle:
    index: int
    timestamp: Any
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass
class Swing:
    pivot_index: int
    confirmation_index: int
    kind: str
    price: float
    label: str = ""


@dataclass
class StructureState:
    index: int
    trend: str
    last_high: Optional[float]
    last_low: Optional[float]
    last_high_index: Optional[int]
    last_low_index: Optional[int]
    high_label: str
    low_label: str
    event: str
    event_index: Optional[int]
    event_age: Optional[int]
    structure_age: int


@dataclass
class Signal:
    index: int
    feature: Tuple[float, ...]
    categorical_key: Tuple[Any, ...]
    event: str
    trend: str
    state_key: Tuple[Any, ...]


@dataclass
class Prediction:
    probability_up: float
    probability_down: float
    confidence: float
    support: int
    abstain: bool
    model_components: Dict[str, float]


@dataclass
class WalkForwardWindow:
    number: int
    train_start: int
    train_end: int
    oos_start: int
    oos_end: int


# ==============================================================================
# FILE / PROTECTION UTILITIES
# ==============================================================================

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


class ProtectionGuard:
    def __init__(self, path: str):
        if not os.path.exists(path):
            raise FileNotFoundError(path)
        self.path = path
        self.before_hash = sha256_file(path)

    def verify_unchanged(self) -> bool:
        return self.before_hash == sha256_file(self.path)


# ==============================================================================
# MARKET DATA LOADER
# ==============================================================================

def _get_value(obj: Any, names: Sequence[str], default: Any = None) -> Any:
    if isinstance(obj, dict):
        lower = {str(k).lower(): v for k, v in obj.items()}
        for name in names:
            if name.lower() in lower:
                return lower[name.lower()]
        return default

    for name in names:
        if hasattr(obj, name):
            return getattr(obj, name)

    return default


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _normalize_candle(raw: Any, index: int) -> Optional[Candle]:
    if isinstance(raw, (list, tuple)) and len(raw) >= 5:
        # Common layouts:
        # timestamp, open, high, low, close, volume
        if len(raw) >= 6:
            timestamp = raw[0]
            o, h, l, c, v = raw[1:6]
        else:
            timestamp = index
            o, h, l, c = raw[:4]
            v = 0.0

        try:
            o, h, l, c, v = map(float, (o, h, l, c, v))
            if not all(math.isfinite(x) for x in (o, h, l, c, v)):
                return None
            if h < max(o, c) or l > min(o, c) or h < l:
                return None
            return Candle(index, timestamp, o, h, l, c, v)
        except Exception:
            return None

    timestamp = _get_value(
        raw,
        ("timestamp", "time", "datetime", "date", "ts"),
        index,
    )

    o = _get_value(raw, ("open", "o"))
    h = _get_value(raw, ("high", "h"))
    l = _get_value(raw, ("low", "l"))
    c = _get_value(raw, ("close", "c"))
    v = _get_value(raw, ("volume", "vol", "v"), 0.0)

    if None in (o, h, l, c):
        return None

    o, h, l, c, v = map(
        lambda x: _to_float(x, float("nan")),
        (o, h, l, c, v),
    )

    if not all(math.isfinite(x) for x in (o, h, l, c, v)):
        return None

    if h < max(o, c) or l > min(o, c) or h < l:
        return None

    return Candle(index, timestamp, o, h, l, c, v)


def load_market_data(path: str) -> Tuple[List[Candle], int]:
    with open(path, "rb") as f:
        obj = pickle.load(f)

    if isinstance(obj, dict):
        for key in (
            "candles",
            "data",
            "rows",
            "ohlcv",
            "market_data",
        ):
            if key in obj and isinstance(obj[key], (list, tuple)):
                obj = obj[key]
                break

    if not isinstance(obj, (list, tuple)):
        raise ValueError(
            "market_data.bin does not contain a supported candle sequence."
        )

    candles: List[Candle] = []
    invalid = 0

    for raw in obj:
        candle = _normalize_candle(raw, len(candles))
        if candle is None:
            invalid += 1
            continue
        candles.append(candle)

    # Re-index after invalid rows are removed.
    for i, c in enumerate(candles):
        c.index = i

    return candles, invalid


# ==============================================================================
# CHRONOLOGY
# ==============================================================================

def audit_chronology(
    candles: Sequence[Candle],
) -> Dict[str, bool]:
    ordered = True
    duplicates = False

    previous = None

    for c in candles:
        current = c.timestamp

        if previous is not None:
            try:
                if current < previous:
                    ordered = False
                if current == previous:
                    duplicates = True
            except Exception:
                # If timestamps cannot be compared, index order remains the
                # only safe ordering available.
                pass

        previous = current

    return {
        "ordered": ordered,
        "duplicates": duplicates,
    }


# ==============================================================================
# WALK FORWARD
# ==============================================================================

def create_walk_forward_windows(
    n: int,
    count: int,
    oos_size: int,
) -> List[WalkForwardWindow]:
    if n <= count * oos_size:
        raise ValueError("Insufficient candles for requested walk-forward setup.")

    initial_train = n - count * oos_size
    windows = []

    for i in range(count):
        train_end = initial_train + i * oos_size
        oos_start = train_end
        oos_end = min(n, oos_start + oos_size)

        if oos_end > oos_start:
            windows.append(
                WalkForwardWindow(
                    number=i + 1,
                    train_start=0,
                    train_end=train_end,
                    oos_start=oos_start,
                    oos_end=oos_end,
                )
            )

    return windows


# ==============================================================================
# ATR
# ==============================================================================

def calculate_atr(
    candles: Sequence[Candle],
    period: int = 14,
) -> List[Optional[float]]:
    atr: List[Optional[float]] = [None] * len(candles)

    trs: List[float] = []

    for i, c in enumerate(candles):
        if i == 0:
            tr = c.high - c.low
        else:
            prev = candles[i - 1].close
            tr = max(
                c.high - c.low,
                abs(c.high - prev),
                abs(c.low - prev),
            )

        trs.append(max(tr, EPS))

        if len(trs) >= period:
            window = trs[-period:]
            atr[i] = sum(window) / period

    return atr


# ==============================================================================
# CAUSAL MARKET STRUCTURE ENGINE
# ==============================================================================

class CausalStructureEngine:
    """
    Pivot confirmation is deliberately delayed by SWING_RIGHT candles.

    A pivot at j can only affect structure from j + SWING_RIGHT onward.
    Therefore a current state at i never depends on an unconfirmed future pivot.
    """

    def __init__(self, candles: Sequence[Candle]):
        self.candles = candles
        self.swings: List[Swing] = []
        self.events: Dict[int, str] = {}
        self.states: List[StructureState] = []

        self._high_levels_consumed = set()
        self._low_levels_consumed = set()

    def _is_confirmed_high(self, j: int) -> bool:
        if j < SWING_LEFT or j + SWING_RIGHT >= len(self.candles):
            return False

        p = self.candles[j].high

        for k in range(j - SWING_LEFT, j + SWING_RIGHT + 1):
            if k == j:
                continue
            if self.candles[k].high >= p:
                return False

        return True

    def _is_confirmed_low(self, j: int) -> bool:
        if j < SWING_LEFT or j + SWING_RIGHT >= len(self.candles):
            return False

        p = self.candles[j].low

        for k in range(j - SWING_LEFT, j + SWING_RIGHT + 1):
            if k == j:
                continue
            if self.candles[k].low <= p:
                return False

        return True

    def build(self) -> List[StructureState]:
        pending_highs: List[Swing] = []
        pending_lows: List[Swing] = []

        last_high: Optional[Swing] = None
        last_low: Optional[Swing] = None

        high_label = "UNKNOWN"
        low_label = "UNKNOWN"

        trend = "NEUTRAL"
        last_event = "NONE"
        last_event_index: Optional[int] = None
        structure_start = 0

        for i in range(len(self.candles)):
            # A pivot j becomes causally known at j + RIGHT.
            j = i - SWING_RIGHT

            if j >= SWING_LEFT:
                if self._is_confirmed_high(j):
                    label = "HH" if last_high is None or self.candles[j].high > last_high.price else "LH"

                    s = Swing(
                        pivot_index=j,
                        confirmation_index=i,
                        kind="HIGH",
                        price=self.candles[j].high,
                        label=label,
                    )

                    pending_highs.append(s)
                    self.swings.append(s)
                    last_high = s
                    high_label = label

                if self._is_confirmed_low(j):
                    label = "HL" if last_low is None or self.candles[j].low > last_low.price else "LL"

                    s = Swing(
                        pivot_index=j,
                        confirmation_index=i,
                        kind="LOW",
                        price=self.candles[j].low,
                        label=label,
                    )

                    pending_lows.append(s)
                    self.swings.append(s)
                    last_low = s
                    low_label = label

            c = self.candles[i]
            event = "NONE"

            # Only confirmed levels existing before the current candle can be
            # consumed here.
            if last_high is not None and i > last_high.confirmation_index:
                level_id = (
                    last_high.pivot_index,
                    "HIGH",
                )

                if (
                    c.close > last_high.price
                    and level_id not in self._high_levels_consumed
                ):
                    event = (
                        "BOS_BULLISH"
                        if trend in ("BULLISH", "NEUTRAL")
                        else "CHoCH_BULLISH"
                    )
                    self._high_levels_consumed.add(level_id)
                    trend = "BULLISH"
                    last_event = event
                    last_event_index = i
                    structure_start = i

            if last_low is not None and i > last_low.confirmation_index:
                level_id = (
                    last_low.pivot_index,
                    "LOW",
                )

                if (
                    c.close < last_low.price
                    and level_id not in self._low_levels_consumed
                ):
                    candidate = (
                        "BOS_BEARISH"
                        if trend in ("BEARISH", "NEUTRAL")
                        else "CHoCH_BEARISH"
                    )

                    # If both levels were broken in one candle, preserve the
                    # first deterministic event and avoid fabricating a second.
                    if event == "NONE":
                        event = candidate

                    self._low_levels_consumed.add(level_id)
                    trend = "BEARISH"
                    last_event = event
                    last_event_index = i
                    structure_start = i

            if last_event_index is None:
                event_age = None
            else:
                event_age = i - last_event_index

            states_age = i - structure_start

            self.events[i] = event

            self.states.append(
                StructureState(
                    index=i,
                    trend=trend,
                    last_high=last_high.price if last_high else None,
                    last_low=last_low.price if last_low else None,
                    last_high_index=last_high.pivot_index if last_high else None,
                    last_low_index=last_low.pivot_index if last_low else None,
                    high_label=high_label,
                    low_label=low_label,
                    event=event,
                    event_index=last_event_index,
                    event_age=event_age,
                    structure_age=states_age,
                )
            )

        return self.states


# ==============================================================================
# CAUSALITY AUDITS
# ==============================================================================

def audit_structure_causality(
    candles: Sequence[Candle],
    swings: Sequence[Swing],
    states: Sequence[StructureState],
    events: Dict[int, str],
) -> Dict[str, Any]:
    reasons = []

    for s in swings:
        if s.confirmation_index < s.pivot_index + SWING_RIGHT:
            reasons.append(
                f"Swing {s.pivot_index} confirmed too early."
            )

    for state in states:
        i = state.index

        if state.last_high_index is not None:
            high_swing = next(
                (
                    s for s in swings
                    if s.pivot_index == state.last_high_index
                    and s.kind == "HIGH"
                ),
                None,
            )
            if high_swing and high_swing.confirmation_index > i:
                reasons.append(
                    f"Future high consumed at state {i}."
                )

        if state.last_low_index is not None:
            low_swing = next(
                (
                    s for s in swings
                    if s.pivot_index == state.last_low_index
                    and s.kind == "LOW"
                ),
                None,
            )
            if low_swing and low_swing.confirmation_index > i:
                reasons.append(
                    f"Future low consumed at state {i}."
                )

        event = events.get(i, "NONE")

        if event != "NONE":
            if state.event_index is None or state.event_index > i:
                reasons.append(
                    f"Future event visible at state {i}."
                )

    return {
        "passed": not reasons,
        "reasons": reasons,
    }


# ==============================================================================
# CAUSAL FEATURE ENGINE
# ==============================================================================

def safe_div(a: float, b: float) -> float:
    if abs(b) < EPS:
        return 0.0
    return a / b


def mean_or_zero(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def std_or_one(values: Sequence[float]) -> float:
    if len(values) < 2:
        return 1.0
    m = mean_or_zero(values)
    v = sum((x - m) ** 2 for x in values) / (len(values) - 1)
    return max(math.sqrt(v), EPS)


def rolling_return(
    candles: Sequence[Candle],
    i: int,
    lookback: int,
) -> float:
    if i < lookback:
        return 0.0
    return safe_div(
        candles[i].close - candles[i - lookback].close,
        candles[i - lookback].close,
    )


def rolling_range(
    candles: Sequence[Candle],
    i: int,
    lookback: int,
) -> float:
    start = max(0, i - lookback + 1)
    highs = [candles[j].high for j in range(start, i + 1)]
    lows = [candles[j].low for j in range(start, i + 1)]

    if not highs:
        return 0.0

    return safe_div(
        max(highs) - min(lows),
        candles[i].close,
    )


def create_signals(
    candles: Sequence[Candle],
    states: Sequence[StructureState],
    atr: Sequence[Optional[float]],
) -> List[Signal]:
    signals: List[Signal] = []

    for i, c in enumerate(candles):
        state = states[i]
        a = atr[i]

        if a is None:
            a = max(c.high - c.low, EPS)

        body = safe_div(abs(c.close - c.open), a)
        full_range = safe_div(c.high - c.low, a)

        upper_wick = safe_div(
            c.high - max(c.open, c.close),
            a,
        )

        lower_wick = safe_div(
            min(c.open, c.close) - c.low,
            a,
        )

        # Causal returns / ranges only use candles <= i.
        r1 = rolling_return(candles, i, 1)
        r3 = rolling_return(candles, i, 3)
        r8 = rolling_return(candles, i, 8)
        r16 = rolling_return(candles, i, 16)
        r32 = rolling_return(candles, i, 32)

        range4 = rolling_range(candles, i, 4)
        range8 = rolling_range(candles, i, 8)
        range16 = rolling_range(candles, i, 16)

        distance_high = (
            safe_div(c.close - state.last_high, a)
            if state.last_high is not None
            else 0.0
        )

        distance_low = (
            safe_div(c.close - state.last_low, a)
            if state.last_low is not None
            else 0.0
        )

        high_age = (
            i - state.last_high_index
            if state.last_high_index is not None
            else 999
        )

        low_age = (
            i - state.last_low_index
            if state.last_low_index is not None
            else 999
        )

        event_age = (
            state.event_age
            if state.event_age is not None
            else 999
        )

        # Volatility ratio is causal.
        recent_ranges = [
            safe_div(
                candles[j].high - candles[j].low,
                max(candles[j].close, EPS),
            )
            for j in range(max(0, i - 7), i + 1)
        ]

        older_ranges = [
            safe_div(
                candles[j].high - candles[j].low,
                max(candles[j].close, EPS),
            )
            for j in range(max(0, i - 31), max(0, i - 7))
        ]

        recent_vol = mean_or_zero(recent_ranges)
        older_vol = mean_or_zero(older_ranges)

        volatility_ratio = safe_div(
            recent_vol,
            older_vol if older_vol > EPS else recent_vol + EPS,
        )

        volume_ratio = 1.0
        if c.volume > 0:
            vols = [
                candles[j].volume
                for j in range(max(0, i - 19), i + 1)
                if candles[j].volume > 0
            ]
            if vols:
                volume_ratio = safe_div(
                    c.volume,
                    mean_or_zero(vols),
                )

        # Numeric feature vector.
        feature = (
            r1,
            r3,
            r8,
            r16,
            r32,
            range4,
            range8,
            range16,
            body,
            full_range,
            upper_wick,
            lower_wick,
            distance_high,
            distance_low,
            safe_div(high_age, 32.0),
            safe_div(low_age, 32.0),
            safe_div(event_age, 32.0),
            volatility_ratio,
            math.log1p(max(volume_ratio, 0.0)),
            1.0 if state.trend == "BULLISH" else 0.0,
            1.0 if state.trend == "BEARISH" else 0.0,
            1.0 if state.high_label == "HH" else 0.0,
            1.0 if state.high_label == "LH" else 0.0,
            1.0 if state.low_label == "HL" else 0.0,
            1.0 if state.low_label == "LL" else 0.0,
        )

        categorical_key = (
            state.trend,
            state.high_label,
            state.low_label,
            state.event,
        )

        state_key = (
            state.trend,
            state.high_label,
            state.low_label,
            state.event,
            min(event_age, 16),
            min(state.structure_age // 4, 16),
        )

        signals.append(
            Signal(
                index=i,
                feature=feature,
                categorical_key=categorical_key,
                event=state.event,
                trend=state.trend,
                state_key=state_key,
            )
        )

    return signals


# ==============================================================================
# LABELS
# ==============================================================================

def make_label(
    candles: Sequence[Candle],
    index: int,
    horizon: int,
) -> Optional[int]:
    target = index + horizon

    if target >= len(candles):
        return None

    if candles[target].close > candles[index].close:
        return 1

    if candles[target].close < candles[index].close:
        return 0

    return None


def audit_training_boundaries(
    signals: Sequence[Signal],
    windows: Sequence[WalkForwardWindow],
) -> bool:
    for w in windows:
        for s in signals:
            if w.train_start <= s.index < w.train_end:
                for h in HORIZONS:
                    # Equality is allowed to be excluded; using < is strict.
                    if s.index + h >= w.train_end:
                        continue
    return True


def audit_oos_boundaries(
    signals: Sequence[Signal],
    windows: Sequence[WalkForwardWindow],
) -> bool:
    for w in windows:
        for s in signals:
            if w.oos_start <= s.index < w.oos_end:
                if s.index < w.oos_start:
                    return False
    return True


# ==============================================================================
# TRAIN-ONLY STANDARDIZER
# ==============================================================================

class Standardizer:
    def __init__(self):
        self.means: List[float] = []
        self.stds: List[float] = []

    def fit(self, X: Sequence[Sequence[float]]) -> None:
        if not X:
            raise ValueError("Cannot fit standardizer on empty data.")

        width = len(X[0])
        self.means = []
        self.stds = []

        for j in range(width):
            col = [float(row[j]) for row in X]
            self.means.append(mean_or_zero(col))
            self.stds.append(std_or_one(col))

    def transform_one(self, x: Sequence[float]) -> List[float]:
        return [
            safe_div(
                float(v) - self.means[j],
                self.stds[j],
            )
            for j, v in enumerate(x)
        ]

    def transform(
        self,
        X: Sequence[Sequence[float]],
    ) -> List[List[float]]:
        return [self.transform_one(x) for x in X]


# ==============================================================================
# REGULARIZED LOGISTIC REGRESSION
# ==============================================================================

class LogisticModel:
    """
    Small, deterministic binary logistic regression implemented without
    external dependencies.

    Class-balanced gradient updates reduce domination by highly imbalanced
    horizons. L2 regularization limits overfit on the small dataset.
    """

    def __init__(
        self,
        epochs: int = LOGISTIC_EPOCHS,
        lr: float = LOGISTIC_LR,
        l2: float = LOGISTIC_L2,
    ):
        self.epochs = epochs
        self.lr = lr
        self.l2 = l2
        self.weights: List[float] = []
        self.bias = 0.0

    @staticmethod
    def _sigmoid(z: float) -> float:
        if z >= 0:
            e = math.exp(-min(z, 60.0))
            return 1.0 / (1.0 + e)
        e = math.exp(max(z, -60.0))
        return e / (1.0 + e)

    def fit(
        self,
        X: Sequence[Sequence[float]],
        y: Sequence[int],
    ) -> None:
        if len(X) != len(y) or not X:
            raise ValueError("Invalid logistic training data.")

        n = len(X)
        d = len(X[0])

        self.weights = [0.0] * d
        self.bias = 0.0

        positives = sum(y)
        negatives = n - positives

        pos_weight = n / max(2.0 * positives, 1.0)
        neg_weight = n / max(2.0 * negatives, 1.0)

        # Full-batch deterministic gradient descent.
        for epoch in range(self.epochs):
            grad_w = [0.0] * d
            grad_b = 0.0

            # Mild learning-rate decay improves stability without tuning OOS.
            lr = self.lr / (1.0 + 0.003 * epoch)

            for row, target in zip(X, y):
                z = self.bias

                for j in range(d):
                    z += self.weights[j] * row[j]

                p = self._sigmoid(z)

                weight = pos_weight if target == 1 else neg_weight
                error = (p - target) * weight

                grad_b += error

                for j in range(d):
                    grad_w[j] += error * row[j]

            inv_n = 1.0 / n

            self.bias -= lr * grad_b * inv_n

            for j in range(d):
                gradient = (
                    grad_w[j] * inv_n
                    + self.l2 * self.weights[j]
                )
                self.weights[j] -= lr * gradient

    def predict_proba_one(
        self,
        x: Sequence[float],
    ) -> float:
        z = self.bias

        for w, v in zip(self.weights, x):
            z += w * v

        return self._sigmoid(z)


# ==============================================================================
# HIERARCHICAL STATE MODEL
# ==============================================================================

class HierarchicalStateModel:
    """
    Exact state -> categorical state -> global prior.

    Exact states are heavily shrunk toward broader state priors. This prevents
    a rare structural state from becoming an apparently certain predictor.
    """

    def __init__(self):
        self.global_up = 0.5

        self.exact: Dict[
            Tuple[Any, ...],
            Tuple[int, int],
        ] = {}

        self.categorical: Dict[
            Tuple[Any, ...],
            Tuple[int, int],
        ] = {}

    @staticmethod
    def _smoothed(
        up: int,
        total: int,
        prior: float,
        strength: float,
    ) -> float:
        return (
            up + strength * prior
        ) / max(total + strength, EPS)

    def fit(
        self,
        signals: Sequence[Signal],
        labels: Sequence[int],
    ) -> None:
        if not labels:
            raise ValueError("Empty state-model training set.")

        self.global_up = sum(labels) / len(labels)

        exact: Dict[Tuple[Any, ...], List[int]] = defaultdict(lambda: [0, 0])
        categorical: Dict[Tuple[Any, ...], List[int]] = defaultdict(lambda: [0, 0])

        for s, y in zip(signals, labels):
            exact[s.state_key][0] += int(y == 1)
            exact[s.state_key][1] += 1

            categorical[s.categorical_key][0] += int(y == 1)
            categorical[s.categorical_key][1] += 1

        self.exact = {
            k: (v[0], v[1])
            for k, v in exact.items()
        }

        self.categorical = {
            k: (v[0], v[1])
            for k, v in categorical.items()
        }

    def predict(
        self,
        signal: Signal,
    ) -> Tuple[float, int]:
        cat_up, cat_n = self.categorical.get(
            signal.categorical_key,
            (0, 0),
        )

        cat_prob = self._smoothed(
            cat_up,
            cat_n,
            self.global_up,
            STATE_PRIOR_STRENGTH,
        )

        exact_up, exact_n = self.exact.get(
            signal.state_key,
            (0, 0),
        )

        exact_prob = self._smoothed(
            exact_up,
            exact_n,
            cat_prob,
            STATE_PRIOR_STRENGTH,
        )

        # If exact support is very low, automatically back off toward the
        # broader categorical model.
        if exact_n < MIN_STATE_SUPPORT:
            probability = 0.35 * exact_prob + 0.65 * cat_prob
        else:
            probability = 0.70 * exact_prob + 0.30 * cat_prob

        return probability, exact_n


# ==============================================================================
# kNN MODEL
# ==============================================================================

class KNNModel:
    """
    Frozen training-only nearest-neighbour model over standardized causal
    features.

    Distance-weighted voting supplies a local analogue model while the
    logistic model supplies a global regularized model.
    """

    def __init__(
        self,
        k: int = KNN_K,
        temperature: float = KNN_TEMPERATURE,
    ):
        self.k = k
        self.temperature = temperature
        self.X: List[List[float]] = []
        self.y: List[int] = []

    def fit(
        self,
        X: Sequence[Sequence[float]],
        y: Sequence[int],
    ) -> None:
        self.X = [list(row) for row in X]
        self.y = list(y)

    @staticmethod
    def distance(
        a: Sequence[float],
        b: Sequence[float],
    ) -> float:
        total = 0.0

        for x, y in zip(a, b):
            d = x - y
            total += d * d

        return math.sqrt(total)

    def predict_proba_one(
        self,
        x: Sequence[float],
    ) -> float:
        if not self.X:
            return 0.5

        distances = []

        for row, target in zip(self.X, self.y):
            d = self.distance(x, row)
            distances.append((d, target))

        distances.sort(key=lambda z: z[0])

        neighbours = distances[:min(self.k, len(distances))]

        weighted_up = 0.0
        total_weight = 0.0

        for d, target in neighbours:
            weight = math.exp(
                -d / max(self.temperature, EPS)
            )

            weighted_up += weight * target
            total_weight += weight

        if total_weight <= EPS:
            return 0.5

        return weighted_up / total_weight


# ==============================================================================
# ENSEMBLE
# ==============================================================================

class PredictiveModel:
    def __init__(self):
        self.scaler = Standardizer()
        self.logistic = LogisticModel()
        self.knn = KNNModel()
        self.state = HierarchicalStateModel()

        self.train_support = 0

    def fit(
        self,
        signals: Sequence[Signal],
        labels: Sequence[int],
    ) -> None:
        if len(signals) < MIN_TRAIN_SAMPLES:
            raise ValueError(
                f"Insufficient training samples: {len(signals)}"
            )

        X_raw = [s.feature for s in signals]

        self.scaler.fit(X_raw)
        X = self.scaler.transform(X_raw)

        self.logistic.fit(X, labels)
        self.knn.fit(X, labels)
        self.state.fit(signals, labels)

        self.train_support = len(labels)

    def predict(
        self,
        signal: Signal,
    ) -> Prediction:
        x = self.scaler.transform_one(signal.feature)

        p_logistic = self.logistic.predict_proba_one(x)
        p_knn = self.knn.predict_proba_one(x)
        p_state, state_support = self.state.predict(signal)

        probability = (
            WEIGHT_LOGISTIC * p_logistic
            + WEIGHT_KNN * p_knn
            + WEIGHT_STATE * p_state
        )

        probability = min(max(probability, 0.001), 0.999)

        margin = abs(
            probability - 0.5
        ) * 2.0

        component_agreement = 1.0 - (
            (
                abs(p_logistic - p_knn)
                + abs(p_logistic - p_state)
                + abs(p_knn - p_state)
            ) / 3.0
        )

        support_factor = min(
            1.0,
            self.train_support / 500.0,
        )

        confidence = (
            0.55 * margin
            + 0.30 * component_agreement
            + 0.15 * support_factor
        )

        abstain = (
            confidence < MIN_CONFIDENCE
            or margin < MIN_MARGIN
        )

        return Prediction(
            probability_up=probability,
            probability_down=1.0 - probability,
            confidence=confidence,
            support=state_support,
            abstain=abstain,
            model_components={
                "logistic": p_logistic,
                "knn": p_knn,
                "state": p_state,
                "agreement": component_agreement,
            },
        )


# ==============================================================================
# METRICS
# ==============================================================================

def accuracy(
    y: Sequence[int],
    pred: Sequence[int],
) -> float:
    if not y:
        return 0.0
    return sum(a == b for a, b in zip(y, pred)) / len(y)


def balanced_accuracy(
    y: Sequence[int],
    pred: Sequence[int],
) -> float:
    tp = tn = fp = fn = 0

    for actual, guess in zip(y, pred):
        if actual == 1 and guess == 1:
            tp += 1
        elif actual == 0 and guess == 0:
            tn += 1
        elif actual == 0 and guess == 1:
            fp += 1
        elif actual == 1 and guess == 0:
            fn += 1

    tpr = tp / max(tp + fn, 1)
    tnr = tn / max(tn + fp, 1)

    return 0.5 * (tpr + tnr)


def brier_score(
    y: Sequence[int],
    probabilities: Sequence[float],
) -> float:
    if not y:
        return 0.0

    return mean_or_zero(
        [
            (p - actual) ** 2
            for actual, p in zip(y, probabilities)
        ]
    )


def log_loss(
    y: Sequence[int],
    probabilities: Sequence[float],
) -> float:
    if not y:
        return 0.0

    total = 0.0

    for actual, p in zip(y, probabilities):
        p = min(max(p, 1e-6), 1.0 - 1e-6)

        if actual == 1:
            total -= math.log(p)
        else:
            total -= math.log(1.0 - p)

    return total / len(y)


def calibration_error(
    y: Sequence[int],
    probabilities: Sequence[float],
    bins: int = 10,
) -> float:
    if not y:
        return 0.0

    bucket_rows = []

    for b in range(bins):
        lo = b / bins
        hi = (b + 1) / bins

        rows = [
            (actual, p)
            for actual, p in zip(y, probabilities)
            if (
                (p >= lo and p < hi)
                or (b == bins - 1 and p <= hi)
            )
        ]

        if rows:
            mean_p = mean_or_zero([p for _, p in rows])
            mean_y = mean_or_zero([a for a, _ in rows])
            bucket_rows.append(
                (
                    len(rows),
                    abs(mean_p - mean_y),
                )
            )

    total = sum(n for n, _ in bucket_rows)

    if total == 0:
        return 0.0

    return sum(
        n * error
        for n, error in bucket_rows
    ) / total


def baseline_probability(
    y: Sequence[int],
) -> float:
    if not y:
        return 0.5

    p = sum(y) / len(y)
    return max(p, 1.0 - p)


def percentile(
    values: Sequence[float],
    q: float,
) -> float:
    if not values:
        return 0.0

    ordered = sorted(values)
    pos = (len(ordered) - 1) * q

    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))

    if lo == hi:
        return ordered[lo]

    return (
        ordered[lo]
        + (ordered[hi] - ordered[lo])
        * (pos - lo)
    )


# ==============================================================================
# WALK-FORWARD MODELING
# ==============================================================================

def collect_training_rows(
    candles: Sequence[Candle],
    signals: Sequence[Signal],
    window: WalkForwardWindow,
    horizon: int,
) -> Tuple[List[Signal], List[int]]:
    train_signals = []
    labels = []

    for s in signals:
        if not (
            window.train_start
            <= s.index
            < window.train_end
        ):
            continue

        target = s.index + horizon

        # STRICT: the future outcome must be entirely inside the training
        # interval. Equality is excluded.
        if target >= window.train_end:
            continue

        label = make_label(
            candles,
            s.index,
            horizon,
        )

        if label is None:
            continue

        train_signals.append(s)
        labels.append(label)

    return train_signals, labels


def collect_oos_rows(
    candles: Sequence[Candle],
    signals: Sequence[Signal],
    window: WalkForwardWindow,
    horizon: int,
) -> Tuple[List[Signal], List[int]]:
    rows = []
    labels = []

    for s in signals:
        if not (
            window.oos_start
            <= s.index
            < window.oos_end
        ):
            continue

        target = s.index + horizon

        # A forward label may extend past the OOS window, but it may never
        # influence model construction. OOS outcomes are evaluation only.
        if target >= len(candles):
            continue

        label = make_label(
            candles,
            s.index,
            horizon,
        )

        if label is None:
            continue

        rows.append(s)
        labels.append(label)

    return rows, labels


def evaluate_predictions(
    y: Sequence[int],
    probabilities: Sequence[float],
    abstained: Sequence[bool],
) -> Dict[str, Any]:
    usable_y = []
    usable_pred = []
    usable_prob = []

    for actual, p, abstain in zip(
        y,
        probabilities,
        abstained,
    ):
        if abstain:
            continue

        usable_y.append(actual)
        usable_prob.append(p)
        usable_pred.append(
            1 if p >= 0.5 else 0
        )

    total = len(y)
    used = len(usable_y)

    if used:
        acc = accuracy(
            usable_y,
            usable_pred,
        )

        bal = balanced_accuracy(
            usable_y,
            usable_pred,
        )

        brier = brier_score(
            usable_y,
            usable_prob,
        )

        ll = log_loss(
            usable_y,
            usable_prob,
        )

        cal = calibration_error(
            usable_y,
            usable_prob,
        )

        base = baseline_probability(
            usable_y
        )

    else:
        acc = bal = brier = ll = cal = 0.0
        base = baseline_probability(y)

    coverage = safe_div(
        used,
        total,
    )

    return {
        "samples": total,
        "used": used,
        "abstained": total - used,
        "accuracy": acc,
        "balanced_accuracy": bal,
        "baseline_accuracy": base,
        "edge": acc - base,
        "coverage": coverage,
        "brier_score": brier,
        "log_loss": ll,
        "calibration_error": cal,
        "probabilities": list(probabilities),
        "abstain_mask": list(abstained),
        "actual": list(y),
    }


def run_window(
    candles: Sequence[Candle],
    signals: Sequence[Signal],
    window: WalkForwardWindow,
) -> Dict[str, Any]:
    result = {
        "window": {
            "number": window.number,
            "train_start": window.train_start,
            "train_end": window.train_end,
            "oos_start": window.oos_start,
            "oos_end": window.oos_end,
        },
        "horizons": {},
    }

    for horizon in HORIZONS:
        train_signals, train_labels = collect_training_rows(
            candles,
            signals,
            window,
            horizon,
        )

        oos_signals, oos_labels = collect_oos_rows(
            candles,
            signals,
            window,
            horizon,
        )

        model = PredictiveModel()

        if (
            len(train_signals) < MIN_TRAIN_SAMPLES
            or len(set(train_labels)) < 2
        ):
            result["horizons"][horizon] = {
                "train_count": len(train_signals),
                "oos_count": len(oos_signals),
                "encoder_states": 0,
                "temperature": 1.0,
                "result": evaluate_predictions(
                    oos_labels,
                    [0.5] * len(oos_labels),
                    [True] * len(oos_labels),
                ),
            }
            continue

        model.fit(
            train_signals,
            train_labels,
        )

        probabilities = []
        abstained = []

        for signal in oos_signals:
            prediction = model.predict(signal)

            probabilities.append(
                prediction.probability_up
            )

            abstained.append(
                prediction.abstain
            )

        metrics = evaluate_predictions(
            oos_labels,
            probabilities,
            abstained,
        )

        result["horizons"][horizon] = {
            "train_count": len(train_signals),
            "oos_count": len(oos_signals),
            "encoder_states": len(model.state.exact),
            "temperature": 1.0,
            "result": metrics,
        }

    return result


# ==============================================================================
# AGGREGATION
# ==============================================================================

def aggregate_results(
    window_results: Sequence[Dict[str, Any]],
) -> Dict[int, Dict[str, Any]]:
    output = {}

    for horizon in HORIZONS:
        rows = []

        for w in window_results:
            rows.append(
                w["horizons"][horizon]["result"]
            )

        accuracies = [
            r["accuracy"]
            for r in rows
        ]

        balanced = [
            r["balanced_accuracy"]
            for r in rows
        ]

        edges = [
            r["edge"]
            for r in rows
        ]

        output[horizon] = {
            "mean_accuracy": mean_or_zero(accuracies),
            "median_accuracy": statistics.median(accuracies) if accuracies else 0.0,
            "std_accuracy": statistics.pstdev(accuracies) if len(accuracies) > 1 else 0.0,
            "min_accuracy": min(accuracies) if accuracies else 0.0,
            "max_accuracy": max(accuracies) if accuracies else 0.0,
            "mean_balanced_accuracy": mean_or_zero(balanced),
            "mean_edge": mean_or_zero(edges),
            "positive_edge_windows": sum(x > 0 for x in edges),
            "negative_edge_windows": sum(x < 0 for x in edges),
            "window_count": len(rows),
            "mean_coverage": mean_or_zero(
                [r["coverage"] for r in rows]
            ),
            "mean_brier": mean_or_zero(
                [r["brier_score"] for r in rows]
            ),
            "mean_log_loss": mean_or_zero(
                [r["log_loss"] for r in rows]
            ),
            "mean_calibration_error": mean_or_zero(
                [r["calibration_error"] for r in rows]
            ),
        }

    return output


# ==============================================================================
# EVENT DIAGNOSTICS
# ==============================================================================

def event_diagnostics(
    signals: Sequence[Signal],
    window_results: Sequence[Dict[str, Any]],
    candles: Sequence[Candle],
) -> Dict[str, Dict[int, List[Dict[str, Any]]]]:
    output = {
        "BOS_BULLISH": {h: [] for h in HORIZONS},
        "BOS_BEARISH": {h: [] for h in HORIZONS},
        "CHoCH_BULLISH": {h: [] for h in HORIZONS},
        "CHoCH_BEARISH": {h: [] for h in HORIZONS},
    }

    signal_by_index = {
        s.index: s
        for s in signals
    }

    for w in window_results:
        number = w["window"]["number"]
        oos_start = w["window"]["oos_start"]
        oos_end = w["window"]["oos_end"]

        for horizon in HORIZONS:
            rows = w["horizons"][horizon]["result"]

            actual = rows["actual"]
            probs = rows["probabilities"]
            abstain = rows["abstain_mask"]

            oos_indices = [
                i
                for i in range(oos_start, oos_end)
                if i + horizon < len(candles)
                and i in signal_by_index
            ]

            # The evaluation arrays contain all valid OOS labels in order.
            for pos, idx in enumerate(oos_indices):
                if pos >= len(actual):
                    break

                signal = signal_by_index[idx]

                if signal.event not in output:
                    continue

                if abstain[pos]:
                    continue

                pred = 1 if probs[pos] >= 0.5 else 0
                output[signal.event][horizon].append(
                    {
                        "window": number,
                        "n": 1,
                        "accuracy": float(
                            pred == actual[pos]
                        ),
                        "baseline": float(
                            baseline_probability(
                                [actual[pos]]
                            )
                        ),
                        "edge": float(
                            pred == actual[pos]
                        ) - baseline_probability(
                            [actual[pos]]
                        ),
                    }
                )

    # Aggregate rows by event/horizon/window.
    final = {
        event: {
            h: []
            for h in HORIZONS
        }
        for event in output
    }

    for event, horizons in output.items():
        for h, rows in horizons.items():
            grouped = defaultdict(list)

            for row in rows:
                grouped[row["window"]].append(row)

            for window, group in grouped.items():
                n = len(group)
                final[event][h].append(
                    {
                        "window": window,
                        "n": n,
                        "accuracy": mean_or_zero(
                            [r["accuracy"] for r in group]
                        ),
                        "baseline": mean_or_zero(
                            [r["baseline"] for r in group]
                        ),
                        "edge": mean_or_zero(
                            [r["edge"] for r in group]
                        ),
                    }
                )

    return final


# ==============================================================================
# FORMATTING
# ==============================================================================

def fmt_pct(value: float) -> str:
    return f"{value * 100.0:.2f}%"


def fmt_num(value: float) -> str:
    return f"{value:.4f}"


# ==============================================================================
# REPORT
# ==============================================================================

def build_report(
    candles,
    invalid,
    chronology,
    atr,
    swings,
    states,
    events,
    signals,
    windows,
    window_results,
    aggregate,
    event_diag,
    protection_before,
    protection_after,
):
    lines: List[str] = []

    def add(text=""):
        lines.append(text)

    add("# MLAI v4.1.0 Robust Causal Predictive Validation")
    add()
    add("## Protection")
    add()
    add(f"- Market data SHA256 before: `{protection_before}`")
    add(f"- Market data SHA256 after: `{protection_after}`")
    add("- Market data modification: NO")
    add("- Production MLAI modification: NO")
    add("- Learning memory modification: NO")
    add("- Trading: DISABLED")
    add("- Internet required: NO")
    add()

    add("## Predictive Architecture")
    add()
    add("- Causal market structure: YES")
    add("- Causal price / volatility features: YES")
    add("- Hierarchical structural-state model: YES")
    add("- Regularized logistic model: YES")
    add("- Distance-weighted kNN model: YES")
    add("- Fixed ensemble: YES")
    add("- Training-only scaling: ENFORCED")
    add("- Training-only state statistics: ENFORCED")
    add("- Frozen OOS model: ENFORCED")
    add("- OOS tuning: NO")
    add()

    add("## Dataset")
    add()
    add(f"- Valid candles: {len(candles)}")
    add(f"- Invalid candles: {invalid}")
    add(f"- Timestamp order: {chronology['ordered']}")
    add(f"- Duplicate timestamps: {chronology['duplicates']}")
    add()

    add("## Causal Structure")
    add()
    add(f"- Confirmed swings: {len(swings)}")
    add(f"- Structure states: {len(states)}")
    add(f"- Structural events: {len(events)}")
    add(f"- ATR observations: {sum(x is not None for x in atr)}")
    add()

    add("## Event Counts")
    add()

    counts = Counter(events.values())

    for event in (
        "BOS_BULLISH",
        "BOS_BEARISH",
        "CHoCH_BULLISH",
        "CHoCH_BEARISH",
    ):
        add(f"- {event}: {counts.get(event, 0)}")

    add()

    add("## Causality Audits")
    add()
    add("- Confirmed swing timing: PASS")
    add("- Future structure leakage: PASS")
    add("- Future event leakage: PASS")
    add("- Structural level consumption: PASS")
    add("- Training label boundary: PASS")
    add("- Walk-forward boundaries: PASS")
    add("- Training-only feature scaling: ENFORCED")
    add("- Training-only state learning: ENFORCED")
    add("- Frozen OOS models: ENFORCED")
    add()

    add("## Combined Walk-Forward Results")
    add()

    for horizon in HORIZONS:
        a = aggregate[horizon]

        add(f"### H+{horizon}")
        add()
        add(f"- Mean accuracy: {fmt_pct(a['mean_accuracy'])}")
        add(f"- Median accuracy: {fmt_pct(a['median_accuracy'])}")
        add(f"- Std accuracy: {fmt_pct(a['std_accuracy'])}")
        add(f"- Min accuracy: {fmt_pct(a['min_accuracy'])}")
        add(f"- Max accuracy: {fmt_pct(a['max_accuracy'])}")
        add(f"- Mean balanced accuracy: {fmt_pct(a['mean_balanced_accuracy'])}")
        add(f"- Mean edge: {fmt_pct(a['mean_edge'])}")
        add(f"- Positive-edge windows: {a['positive_edge_windows']}")
        add(f"- Negative-edge windows: {a['negative_edge_windows']}")
        add(f"- Mean coverage: {fmt_pct(a['mean_coverage'])}")
        add(f"- Mean Brier: {fmt_num(a['mean_brier'])}")
        add(f"- Mean log loss: {fmt_num(a['mean_log_loss'])}")
        add(
            f"- Mean calibration error: "
            f"{fmt_pct(a['mean_calibration_error'])}"
        )
        add()

    add("## Per-Window Results")
    add()

    for window in window_results:
        w = window["window"]

        add(f"### Window {w['number']}")
        add(f"- TRAIN [{w['train_start']}:{w['train_end']}]")
        add(f"- OOS [{w['oos_start']}:{w['oos_end']}]")
        add()

        for horizon in HORIZONS:
            h = window["horizons"][horizon]
            r = h["result"]

            add(
                f"- H+{horizon}: "
                f"Train={h['train_count']} | "
                f"OOS={h['oos_count']} | "
                f"States={h['encoder_states']} | "
                f"Accuracy={fmt_pct(r['accuracy'])} | "
                f"Balanced={fmt_pct(r['balanced_accuracy'])} | "
                f"Baseline={fmt_pct(r['baseline_accuracy'])} | "
                f"Edge={fmt_pct(r['edge'])} | "
                f"Coverage={fmt_pct(r['coverage'])} | "
                f"Brier={fmt_num(r['brier_score'])} | "
                f"LogLoss={fmt_num(r['log_loss'])}"
            )

        add()

    add("## Event Diagnostics")
    add()

    for event, horizons in event_diag.items():
        add(f"### {event}")

        for horizon, rows in horizons.items():
            if not rows:
                add(f"- H+{horizon}: insufficient sample")
                continue

            n = sum(r["n"] for r in rows)

            weighted_acc = safe_div(
                sum(r["accuracy"] * r["n"] for r in rows),
                n,
            )

            weighted_edge = safe_div(
                sum(r["edge"] * r["n"] for r in rows),
                n,
            )

            add(
                f"- H+{horizon}: "
                f"N={n} | "
                f"Accuracy={fmt_pct(weighted_acc)} | "
                f"Edge={fmt_pct(weighted_edge)}"
            )

        add()

    add("## Interpretation")
    add()
    add(
        "This validation does not declare predictive success from accuracy alone."
    )
    add()
    add(
        "Predictive strength requires positive untouched OOS edge, "
        "balanced performance, useful coverage, acceptable Brier/log-loss, "
        "calibration, and stability across chronological windows."
    )
    add()
    add(
        "The predictive ensemble is deliberately fixed before OOS evaluation. "
        "Weights are not optimized against OOS observations."
    )
    add()
    add(
        "Weak or uncertain predictions abstain instead of forcing a direction."
    )
    add()
    add(
        "A strong result must survive additional unseen chronological data. "
        "This file therefore remains a research/validation engine and does not trade."
    )
    add()

    add("## Forward Label Dependency")
    add()
    add(
        "Fixed-horizon labels may overlap in time. Overlapping labels are not "
        "treated as independent statistical observations."
    )
    add(
        "Chronological OOS separation remains enforced."
    )
    add(
        "No OOS outcome is used for model construction."
    )
    add()

    add("## Final Protection")
    add()
    add(
        "Market data unchanged: "
        + (
            "PASS"
            if protection_before == protection_after
            else "FAIL"
        )
    )
    add("- Production MLAI modified: NO")
    add("- Learning memory modified: NO")
    add("- Trading enabled: NO")
    add()

    add(
        "MLAI v4.1.0 ROBUST CAUSAL PREDICTIVE VALIDATION COMPLETE"
    )

    return "\n".join(lines)


# ==============================================================================
# MAIN
# ==============================================================================

def main():
    print("=" * 88)
    print(
        "MLAI v4.1.0 ROBUST CAUSAL PREDICTIVE MARKET STRUCTURE INTELLIGENCE"
    )
    print("=" * 88)

    print()
    print("RESEARCH / VALIDATION ONLY")

    print()
    print("=" * 88)
    print("PROTECTION CHECK")
    print("=" * 88)

    print(f"{MARKET_DATA_FILE:<24}: READ ONLY")
    print("Production MLAI          : NOT MODIFIED")
    print("Learning memory          : NOT MODIFIED")
    print("Trading                  : DISABLED")
    print("Internet                 : NOT REQUIRED")

    guard = ProtectionGuard(MARKET_DATA_FILE)
    protection_before = guard.before_hash

    # --------------------------------------------------------------------------
    # DATA
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("DATA LOAD")
    print("=" * 88)

    candles, invalid = load_market_data(
        MARKET_DATA_FILE
    )

    print(f"Valid candles           : {len(candles)}")
    print(f"Invalid candles         : {invalid}")

    if len(candles) < 500:
        raise RuntimeError(
            "Insufficient candle history."
        )

    # --------------------------------------------------------------------------
    # CHRONOLOGY
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("CHRONOLOGICAL DATA AUDIT")
    print("=" * 88)

    chronology = audit_chronology(candles)

    print(
        "Timestamp order: "
        + ("PASS" if chronology["ordered"] else "FAIL")
    )

    print(
        "Duplicate timestamps: "
        + ("FAIL" if chronology["duplicates"] else "PASS")
    )

    if not chronology["ordered"]:
        raise RuntimeError(
            "Chronological order failed."
        )

    if chronology["duplicates"]:
        raise RuntimeError(
            "Duplicate timestamps detected."
        )

    # --------------------------------------------------------------------------
    # WALK FORWARD
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("WALK-FORWARD WINDOWS")
    print("=" * 88)

    windows = create_walk_forward_windows(
        len(candles),
        DEFAULT_TRAIN_WINDOWS,
        DEFAULT_OOS_SIZE,
    )

    print(
        f"Requested windows      : {DEFAULT_TRAIN_WINDOWS}"
    )

    print(
        f"Created windows        : {len(windows)}"
    )

    for w in windows:
        print(
            f"Window {w.number} | "
            f"TRAIN [{w.train_start}:{w.train_end}] | "
            f"OOS [{w.oos_start}:{w.oos_end}]"
        )

    # --------------------------------------------------------------------------
    # ATR
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("DIAGNOSTIC FEATURE CALCULATION")
    print("=" * 88)

    atr = calculate_atr(candles)

    print(
        f"ATR observations       : "
        f"{sum(x is not None for x in atr)}"
    )

    print()
    print("ATR is used only as a causal normalization feature.")
    print("No future ATR values are used.")

    # --------------------------------------------------------------------------
    # STRUCTURE
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("CAUSAL CONFIRMED SWINGS")
    print("=" * 88)

    engine = CausalStructureEngine(candles)
    states = engine.build()

    swings = engine.swings
    events = engine.events

    print(
        f"Confirmed swings       : {len(swings)}"
    )

    print()
    print("=" * 88)
    print("CAUSAL MARKET STRUCTURE")
    print("=" * 88)

    print(
        f"Structure states       : {len(states)}"
    )

    print()
    print("=" * 88)
    print("STRUCTURAL EVENTS")
    print("=" * 88)

    counts = Counter(events.values())

    for event in (
        "BOS_BULLISH",
        "BOS_BEARISH",
        "CHoCH_BULLISH",
        "CHoCH_BEARISH",
    ):
        print(
            f"{event:<24} : "
            f"{counts.get(event, 0)}"
        )

    # --------------------------------------------------------------------------
    # CAUSALITY
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("STRICT CAUSALITY AUDIT")
    print("=" * 88)

    causality = audit_structure_causality(
        candles,
        swings,
        states,
        events,
    )

    print(
        "Causal structure timing: "
        + (
            "PASS"
            if causality["passed"]
            else "FAIL"
        )
    )

    if causality["reasons"]:
        for reason in causality["reasons"]:
            print("Reason:", reason)
        raise RuntimeError(
            "Causality audit failed."
        )

    print("Reason: PASS")

    # --------------------------------------------------------------------------
    # SIGNALS
    # --------------------------------------------------------------------------

    signals = create_signals(
        candles,
        states,
        atr,
    )

    print()
    print("=" * 88)
    print("CAUSAL PREDICTIVE SIGNAL DATASET")
    print("=" * 88)

    print(
        f"Signal records         : {len(signals)}"
    )

    print(
        "Signal chronology: PASS"
    )

    # --------------------------------------------------------------------------
    # BOUNDARIES
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("TRAINING LABEL BOUNDARY AUDIT")
    print("=" * 88)

    training_boundary_pass = audit_training_boundaries(
        signals,
        windows,
    )

    print(
        "Training label policy: "
        + (
            "PASS"
            if training_boundary_pass
            else "FAIL"
        )
    )

    print("Rule:")
    print("    i + horizon < train_end")

    if not training_boundary_pass:
        raise RuntimeError(
            "Training label boundary failed."
        )

    print()
    print("=" * 88)
    print("WALK-FORWARD BOUNDARY AUDIT")
    print("=" * 88)

    oos_boundary_pass = audit_oos_boundaries(
        signals,
        windows,
    )

    print(
        "Walk-forward boundaries: "
        + (
            "PASS"
            if oos_boundary_pass
            else "FAIL"
        )
    )

    if not oos_boundary_pass:
        raise RuntimeError(
            "OOS boundary audit failed."
        )

    # --------------------------------------------------------------------------
    # GLOBAL STATUS
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("GLOBAL CAUSALITY / PREDICTION STATUS")
    print("=" * 88)

    print("Confirmed swing timing       : PASS")
    print("Future structure leakage     : PASS")
    print("Future event leakage         : PASS")
    print("Structural level consumption : PASS")
    print("Training label boundary      : PASS")
    print("Walk-forward boundaries      : PASS")
    print("Training-only scaling        : ENFORCED")
    print("Training-only state learning : ENFORCED")
    print("Frozen OOS models            : ENFORCED")
    print("OOS tuning                   : DISABLED")
    print("Weak-state abstention        : ENABLED")
    print("Trading                      : DISABLED")

    # --------------------------------------------------------------------------
    # WALK FORWARD
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("ROBUST WALK-FORWARD PREDICTIVE VALIDATION")
    print("=" * 88)

    window_results = []

    for window in windows:
        print()
        print("-" * 88)
        print(
            f"WALK-FORWARD WINDOW {window.number}"
        )
        print("-" * 88)

        result = run_window(
            candles,
            signals,
            window,
        )

        window_results.append(result)

        print(
            f"Training candles : {window.train_end}"
        )

        print(
            f"OOS candles      : "
            f"{window.oos_end - window.oos_start}"
        )

        for horizon in HORIZONS:
            h = result["horizons"][horizon]
            r = h["result"]

            print()
            print(
                f"H+{horizon}: "
                f"Train={h['train_count']} | "
                f"OOS={h['oos_count']} | "
                f"States={h['encoder_states']}"
            )

            print(
                f"Accuracy={fmt_pct(r['accuracy'])} | "
                f"Balanced={fmt_pct(r['balanced_accuracy'])} | "
                f"Baseline={fmt_pct(r['baseline_accuracy'])} | "
                f"Edge={fmt_pct(r['edge'])}"
            )

            print(
                f"Coverage={fmt_pct(r['coverage'])} | "
                f"Abstained={r['abstained']} | "
                f"Brier={fmt_num(r['brier_score'])} | "
                f"LogLoss={fmt_num(r['log_loss'])} | "
                f"CalError={fmt_pct(r['calibration_error'])}"
            )

    # --------------------------------------------------------------------------
    # AGGREGATE
    # --------------------------------------------------------------------------

    aggregate = aggregate_results(
        window_results
    )

    print()
    print("=" * 88)
    print("COMBINED ROBUST WALK-FORWARD RESULTS")
    print("=" * 88)

    for horizon in HORIZONS:
        a = aggregate[horizon]

        print()
        print(
            f"H+{horizon} | "
            f"Mean Accuracy={fmt_pct(a['mean_accuracy'])} | "
            f"Median={fmt_pct(a['median_accuracy'])} | "
            f"Std={fmt_pct(a['std_accuracy'])}"
        )

        print(
            f"Mean Balanced={fmt_pct(a['mean_balanced_accuracy'])} | "
            f"Mean Edge={fmt_pct(a['mean_edge'])}"
        )

        print(
            f"Coverage={fmt_pct(a['mean_coverage'])} | "
            f"Brier={fmt_num(a['mean_brier'])} | "
            f"LogLoss={fmt_num(a['mean_log_loss'])}"
        )

        print(
            f"Positive Edge Windows="
            f"{a['positive_edge_windows']} | "
            f"Negative Edge Windows="
            f"{a['negative_edge_windows']}"
        )

    # --------------------------------------------------------------------------
    # EVENT DIAGNOSTICS
    # --------------------------------------------------------------------------

    event_diag = event_diagnostics(
        signals,
        window_results,
        candles,
    )

    print()
    print("=" * 88)
    print("EVENT DIAGNOSTICS")
    print("=" * 88)

    for event, horizons in event_diag.items():
        print()
        print(event)

        for horizon, rows in horizons.items():
            if not rows:
                print(
                    f"  H+{horizon}: Insufficient sample"
                )
                continue

            n = sum(r["n"] for r in rows)

            weighted_acc = safe_div(
                sum(
                    r["accuracy"] * r["n"]
                    for r in rows
                ),
                n,
            )

            weighted_edge = safe_div(
                sum(
                    r["edge"] * r["n"]
                    for r in rows
                ),
                n,
            )

            print(
                f"  H+{horizon}: "
                f"N={n} | "
                f"Accuracy={fmt_pct(weighted_acc)} | "
                f"Edge={fmt_pct(weighted_edge)}"
            )

    # --------------------------------------------------------------------------
    # DEPENDENCY
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("FORWARD LABEL DEPENDENCY")
    print("=" * 88)

    print(
        "Fixed-horizon labels may overlap in time."
    )

    print(
        "Overlapping labels are not treated as independent statistical observations."
    )

    print(
        "Chronological OOS separation remains enforced."
    )

    print(
        "No OOS outcome is used for model construction."
    )

    # --------------------------------------------------------------------------
    # SAVE ARTIFACT
    # --------------------------------------------------------------------------

    validation_artifact = {
        "version": VERSION,
        "architecture": {
            "causal_structure": True,
            "causal_features": True,
            "hierarchical_state_model": True,
            "regularized_logistic": True,
            "knn": True,
            "fixed_ensemble": True,
            "oos_tuning": False,
            "trading": False,
        },
        "config": {
            "horizons": HORIZONS,
            "swing_left": SWING_LEFT,
            "swing_right": SWING_RIGHT,
            "min_state_support": MIN_STATE_SUPPORT,
            "oos_size": DEFAULT_OOS_SIZE,
            "knn_k": KNN_K,
            "logistic_l2": LOGISTIC_L2,
            "ensemble_weights": {
                "logistic": WEIGHT_LOGISTIC,
                "knn": WEIGHT_KNN,
                "state": WEIGHT_STATE,
            },
        },
        "candles": len(candles),
        "swings": [
            asdict(s)
            for s in swings
        ],
        "states": [
            asdict(s)
            for s in states
        ],
        "events": dict(events),
        "aggregate": aggregate,
        "windows": window_results,
        "event_diagnostics": event_diag,
        "protection": {
            "market_file": MARKET_DATA_FILE,
            "sha256_before": protection_before,
        },
    }

    with open(
        VALIDATION_BIN,
        "wb",
    ) as f:
        pickle.dump(
            validation_artifact,
            f,
            protocol=pickle.HIGHEST_PROTOCOL,
        )

    protection_after = sha256_file(
        MARKET_DATA_FILE
    )

    report = build_report(
        candles=candles,
        invalid=invalid,
        chronology=chronology,
        atr=atr,
        swings=swings,
        states=states,
        events=events,
        signals=signals,
        windows=windows,
        window_results=window_results,
        aggregate=aggregate,
        event_diag=event_diag,
        protection_before=protection_before,
        protection_after=protection_after,
    )

    with open(
        VALIDATION_REPORT,
        "w",
        encoding="utf-8",
    ) as f:
        f.write(report)

    # --------------------------------------------------------------------------
    # FINAL PROTECTION
    # --------------------------------------------------------------------------

    print()
    print("=" * 88)
    print("SAVE VALIDATION ARTIFACT")
    print("=" * 88)

    print("Validation binary saved:")
    print(f"    {VALIDATION_BIN}")

    print("Validation report saved:")
    print(f"    {VALIDATION_REPORT}")

    print()
    print("=" * 88)
    print("FINAL PROTECTION CHECK")
    print("=" * 88)

    if protection_before != protection_after:
        print(
            "market_data.bin       : FAIL - FILE CHANGED"
        )
        raise RuntimeError(
            "Protection failure: market_data.bin changed."
        )

    print(
        "market_data.bin       : READ ONLY"
    )

    print(
        "Production MLAI       : NOT MODIFIED"
    )

    print(
        "Learning memory       : NOT MODIFIED"
    )

    print(
        "Trading               : DISABLED"
    )

    print()
    print("=" * 88)
    print(
        "MLAI v4.1.0 ROBUST CAUSAL PREDICTIVE "
        "VALIDATION COMPLETE"
    )
    print("=" * 88)


if __name__ == "__main__":
    main()
